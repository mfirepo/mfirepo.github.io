import sys
import json
import base64
import urllib.request
import urllib.parse
import urllib.error
import xbmcplugin
import xbmcgui
import xbmcaddon
import xbmcvfs
import resolveurl
import time
import hashlib
import os
import sqlite3

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_VERSION = ADDON.getAddonInfo('version')
ADDON_PATH = ADDON.getAddonInfo('path')
PLUGIN_KEY = "plugin.video.neo_flix"
HANDLE = int(sys.argv[1])

SECURITY_XML_MD5_HASH = "a4ce63b1f4906d367ff2e0d45e3c363e"

REQUIRED_REPO_IDS = [
    "repository.cMaNWizard",
    "repository.madforit",
]

REQUIRED_REPO_NAME = "cMans Repo"

SECURITY_XML_URL = "https://bitbucket.org/halcyonhal/db/raw/main/neosecurity.xml"
SECURITY_CACHE_TIME = 86400
SECURITY_CACHE_FILE = xbmcvfs.translatePath(f"special://temp/{ADDON_ID}_security_cache.xml")

# Live stream extensions and patterns
LIVE_STREAM_EXTENSIONS = ['.m3u8', '.m3u', '.mpd', '.ism', '.ts']
LIVE_STREAM_KEYWORDS = ['live', 'stream', 'm3u8', 'hls', 'dash']

def log(message, level=xbmc.LOGINFO):
    xbmc.log(f"[{ADDON_NAME} v{ADDON_VERSION}] {message}", level)

def calculate_md5_hash(content):
    if not content:
        return None
    return hashlib.md5(content.encode('utf-8')).hexdigest()

def verify_security_xml_hash(xml_content):
    if not SECURITY_XML_MD5_HASH or SECURITY_XML_MD5_HASH == "YOUR_SECURITY_XML_MD5_HASH_HERE":
        log("Security XML MD5 hash not configured properly", xbmc.LOGERROR)
        return False
    
    content_hash = calculate_md5_hash(xml_content)
    if content_hash == SECURITY_XML_MD5_HASH:
        log("Security XML MD5 hash verification successful", xbmc.LOGINFO)
        return True
    else:
        log(f"Security XML MD5 hash mismatch. Expected: {SECURITY_XML_MD5_HASH}, Got: {content_hash}", xbmc.LOGERROR)
        return False

def verify_repository_installed():
    addons_path = xbmcvfs.translatePath("special://home/addons/")
    
    for repo_id in REQUIRED_REPO_IDS:
        repo_path = os.path.join(addons_path, repo_id)
        
        if xbmcvfs.exists(repo_path):
            log(f"Required repository found: {repo_id}", xbmc.LOGINFO)
            return True
    
    try:
        db_path = xbmcvfs.translatePath("special://database/Addons33.db")
        
        if xbmcvfs.exists(db_path):
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            
            placeholders = ','.join('?' * len(REQUIRED_REPO_IDS))
            cursor.execute(f"SELECT addonID FROM installed WHERE addonID IN ({placeholders})", REQUIRED_REPO_IDS)
            result = cursor.fetchone()
            
            conn.close()
            
            if result:
                log(f"Required repository found in database: {result[0]}", xbmc.LOGINFO)
                return True
    except Exception as e:
        log(f"Error checking database for repository: {e}", xbmc.LOGERROR)
    
    repos_xml_path = xbmcvfs.translatePath("special://home/addons/repositories.xml")
    
    if xbmcvfs.exists(repos_xml_path):
        try:
            import xml.etree.ElementTree as ET
            
            with xbmcvfs.File(repos_xml_path, 'r') as f:
                xml_content = f.read()
            
            if xml_content:
                root = ET.fromstring(xml_content)
                
                for repo in root.findall(".//info"):
                    addon_id = repo.get("id")
                    if addon_id and addon_id in REQUIRED_REPO_IDS:
                        log(f"Required repository found in repositories.xml: {addon_id}", xbmc.LOGINFO)
                        return True
        except Exception as e:
            log(f"Error parsing repositories.xml: {e}", xbmc.LOGERROR)
    
    return False

def show_repository_required_message():
    message = f"{ADDON_NAME} requires {REQUIRED_REPO_NAME} to function properly.\n\nPlease install the repository ZIP file to access content."
    
    xbmcgui.Dialog().ok("Repository Required", message)

def is_playback_allowed():
    return verify_repository_installed()

def get_url(**kwargs):
    return f"{sys.argv[0]}?{urllib.parse.urlencode(kwargs)}"

def encrypt(text, key):
    try:
        encrypted_bytes = bytes([ord(c) ^ ord(key[i % len(key)]) for i, c in enumerate(text)])
        return base64.urlsafe_b64encode(encrypted_bytes).decode()
    except Exception as e:
        return ""

def decrypt(encrypted_text, key):
    try:
        encrypted_bytes = base64.urlsafe_b64decode(encrypted_text.encode())
        decrypted_chars = [chr(b ^ ord(key[i % len(key)])) for i, b in enumerate(encrypted_bytes)]
        return ''.join(decrypted_chars)
    except Exception as e:
        xbmcgui.Dialog().notification('Decryption Error', 'Failed to decode stream URL.', xbmcgui.NOTIFICATION_ERROR)
        return ""

def fetch_json(url):
    try:
        req = urllib.request.Request(url, headers={'User-Agent': f'{ADDON_NAME}/{ADDON_VERSION} (Kodi)'})
        with urllib.request.urlopen(req, timeout=30) as response:
            return json.loads(response.read().decode())
    except urllib.error.URLError as e:
        xbmcgui.Dialog().notification('Connection Error', 'Failed to fetch content. Check your internet.', xbmcgui.NOTIFICATION_ERROR)
    except json.JSONDecodeError as e:
        xbmcgui.Dialog().notification('Data Error', 'Invalid content received from server.', xbmcgui.NOTIFICATION_ERROR)
    except Exception as e:
        pass
    return []

def fetch_security_xml():
    try:
        req = urllib.request.Request(SECURITY_XML_URL, headers={
            'User-Agent': f'{ADDON_NAME}/{ADDON_VERSION} (Kodi)',
        })
        
        with urllib.request.urlopen(req, timeout=15) as response:
            if response.status == 200:
                xml_content = response.read().decode()
                return xml_content
            else:
                log(f"Security server returned status: {response.status}", xbmc.LOGERROR)
                return None
    except Exception as e:
        log(f"Error fetching security XML: {e}", xbmc.LOGERROR)
        return None

def validate_security_xml(xml_content):
    try:
        if not xml_content:
            return False
            
        if not verify_security_xml_hash(xml_content):
            log("Security XML failed MD5 hash verification", xbmc.LOGERROR)
            return False
            
        import xml.etree.ElementTree as ET
        root = ET.fromstring(xml_content)
        
        for addon_elem in root.findall('.//addon'):
            addon_id = addon_elem.get('id')
            if addon_id == ADDON_ID:
                status = addon_elem.get('status', 'enabled')
                if status == 'enabled':
                    log(f"Addon {ADDON_ID} found in security XML with status: {status}", xbmc.LOGINFO)
                    return True
                    
        log(f"Addon {ADDON_ID} not found in security XML or not enabled", xbmc.LOGINFO)
        return False
        
    except Exception as e:
        log(f"Error validating security XML: {e}", xbmc.LOGERROR)
        return False

def check_cached_security():
    try:
        if xbmcvfs.exists(SECURITY_CACHE_FILE):
            cache_time = os.path.getmtime(SECURITY_CACHE_FILE)
            current_time = time.time()
            
            if current_time - cache_time < SECURITY_CACHE_TIME:
                with xbmcvfs.File(SECURITY_CACHE_FILE, 'r') as f:
                    xml_content = f.read()
                
                if validate_security_xml(xml_content):
                    log("Using cached security validation", xbmc.LOGINFO)
                    return True
    except:
        pass
    
    return False

def cache_security_validation(xml_content):
    try:
        with xbmcvfs.File(SECURITY_CACHE_FILE, 'w') as f:
            f.write(xml_content)
        log("Security XML cached successfully", xbmc.LOGINFO)
    except Exception as e:
        log(f"Error caching security XML: {e}", xbmc.LOGERROR)

def execute_security_validation():
    if check_cached_security():
        return True
    
    xml_content = fetch_security_xml()
    
    if not xml_content:
        xbmcgui.Dialog().ok('Connection Error', 'Could not contact authorization server. Please check your internet connection.')
        return False
    
    if not validate_security_xml(xml_content):
        xbmcgui.Dialog().ok('Authorization Error', 'This addon is not authorized to function. Please contact support.')
        return False
    
    cache_security_validation(xml_content)
    
    return True

def is_security_valid():
    try:
        return execute_security_validation()
    except Exception as e:
        log(f"Security validation error: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok('Security Error', 'An error occurred during security verification.')
        return False

def is_live_stream_url(url):
    """Check if URL is a live stream"""
    if not url:
        return False
    
    url_lower = url.lower()
    
    # Check for live stream extensions
    for ext in LIVE_STREAM_EXTENSIONS:
        if ext in url_lower:
            return True
    
    # Check for live stream keywords in URL
    for keyword in LIVE_STREAM_KEYWORDS:
        if keyword in url_lower:
            return True
    
    # Check for common live stream patterns
    if '/live/' in url_lower or '/stream/' in url_lower:
        return True
    
    return False

def setup_inputstream_adaptive(list_item, url):
    """Setup InputStream Adaptive with optimal settings for M3U8"""
    try:
        # Check if InputStream Adaptive is available
        if xbmc.getCondVisibility('System.HasAddon(inputstream.adaptive)'):
            list_item.setProperty('inputstream', 'inputstream.adaptive')
            list_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
            
            # Add optimal settings for M3U8 playback
            list_item.setProperty('inputstream.adaptive.stream_headers', 
                                 f'User-Agent=Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36')
            
            # Set manifest update parameters
            list_item.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')
            
            # Enable better segment handling
            list_item.setProperty('inputstream.adaptive.max_resolution', '9999')
            
            log("InputStream Adaptive configured for HLS stream", xbmc.LOGINFO)
            return True
        else:
            log("InputStream Adaptive not available", xbmc.LOGWARNING)
            return False
    except Exception as e:
        log(f"Error setting up InputStream Adaptive: {e}", xbmc.LOGERROR)
        return False

def add_common_headers(list_item, url):
    """Add common headers to handle various M3U8 servers"""
    try:
        # Common headers that help with M3U8 playback
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Accept': '*/*',
            'Accept-Language': 'en-US,en;q=0.9',
            'Accept-Encoding': 'gzip, deflate, br',
            'Connection': 'keep-alive',
            'Sec-Fetch-Dest': 'empty',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Site': 'cross-site',
        }
        
        # Build headers string
        header_string = '&'.join([f'{k}={urllib.parse.quote(v)}' for k, v in headers.items()])
        list_item.setProperty('inputstream.adaptive.stream_headers', header_string)
        list_item.setProperty('http-headers', header_string)
        
        log("Added common headers for M3U8 playback", xbmc.LOGINFO)
        return True
    except Exception as e:
        log(f"Error adding headers: {e}", xbmc.LOGERROR)
        return False

def play_m3u8_stream(url, list_item):
    """Enhanced M3U8 playback with multiple fallback methods"""
    methods = [
        # Method 1: InputStream Adaptive with full configuration
        lambda: play_m3u8_method1(url, list_item),
        # Method 2: Simple InputStream Adaptive
        lambda: play_m3u8_method2(url, list_item),
        # Method 3: Direct playback without inputstream
        lambda: play_m3u8_method3(url, list_item),
    ]
    
    for i, method in enumerate(methods):
        log(f"Trying M3U8 playback method {i+1}", xbmc.LOGINFO)
        try:
            if method():
                log(f"M3U8 playback successful with method {i+1}", xbmc.LOGINFO)
                return True
        except Exception as e:
            log(f"Method {i+1} failed: {e}", xbmc.LOGWARNING)
            continue
    
    return False

def play_m3u8_method1(url, list_item):
    """Method 1: Full InputStream Adaptive configuration"""
    if not setup_inputstream_adaptive(list_item, url):
        return False
    
    add_common_headers(list_item, url)
    
    # Set additional properties for better HLS handling
    list_item.setMimeType('application/vnd.apple.mpegurl')
    list_item.setContentLookup(False)
    list_item.setProperty('IsPlayable', 'true')
    list_item.setPath(url)
    
    xbmcplugin.setResolvedUrl(HANDLE, True, list_item)
    return True

def play_m3u8_method2(url, list_item):
    """Method 2: Simple InputStream Adaptive"""
    if xbmc.getCondVisibility('System.HasAddon(inputstream.adaptive)'):
        list_item.setProperty('inputstream', 'inputstream.adaptive')
        list_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
        list_item.setMimeType('application/vnd.apple.mpegurl')
        list_item.setContentLookup(False)
        list_item.setPath(url)
        
        xbmcplugin.setResolvedUrl(HANDLE, True, list_item)
        return True
    return False

def play_m3u8_method3(url, list_item):
    """Method 3: Direct playback without inputstream"""
    list_item.setMimeType('application/vnd.apple.mpegurl')
    list_item.setContentLookup(False)
    list_item.setPath(url)
    
    xbmcplugin.setResolvedUrl(HANDLE, True, list_item)
    return True

def play_video(link):
    if not is_security_valid():
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
        
    if not is_playback_allowed():
        show_repository_required_message()
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
        
    url = decrypt(link, ADDON_ID)
    if not url:
        log("Failed to decrypt URL", xbmc.LOGERROR)
        return
        
    list_item = xbmcgui.ListItem()
    
    try:
        log(f"Attempting to play URL: {url[:100]}...", xbmc.LOGINFO)
        
        # Check if it's an M3U8 stream
        if '.m3u8' in url.lower():
            if play_m3u8_stream(url, list_item):
                log("M3U8 stream playback initiated successfully", xbmc.LOGINFO)
                return
            else:
                log("All M3U8 playback methods failed", xbmc.LOGERROR)
                raise Exception("All M3U8 playback methods failed")
        
        # Check if it's a live stream
        elif is_live_stream_url(url):
            if play_live_stream(url, list_item):
                log("Live stream playback initiated successfully", xbmc.LOGINFO)
                return
            else:
                log("Live stream playback failed", xbmc.LOGWARNING)
        
        # For other stream types, try ResolveURL
        resolved_url = resolveurl.resolve(url)
        if resolved_url and resolved_url != url:
            log(f"ResolveURL resolved URL: {resolved_url[:100]}...", xbmc.LOGINFO)
            list_item.setPath(resolved_url)
            list_item.setContentLookup(False)
            xbmcplugin.setResolvedUrl(HANDLE, True, list_item)
        else:
            # Final fallback - try direct playback
            log(f"Using direct playback: {url[:100]}...", xbmc.LOGINFO)
            list_item.setPath(url)
            list_item.setContentLookup(False)
            xbmcplugin.setResolvedUrl(HANDLE, True, list_item)
                
    except Exception as e:
        log(f"Playback error: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Playback Error', 'Could not play this stream.', xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(HANDLE, False, list_item)

def play_live_stream(url, list_item):
    """Enhanced live stream playback"""
    try:
        log(f"Attempting to play live stream: {url}", xbmc.LOGINFO)
        
        # For M3U8 live streams, use the enhanced M3U8 player
        if '.m3u8' in url.lower():
            return play_m3u8_stream(url, list_item)
        
        # For other live stream types
        if '.mpd' in url.lower() or 'dash' in url.lower():
            list_item.setMimeType('application/dash+xml')
            list_item.setProperty('inputstream', 'inputstream.adaptive')
            list_item.setProperty('inputstream.adaptive.manifest_type', 'mpd')
        else:
            list_item.setProperty('inputstream', 'inputstream.adaptive')
        
        # Set live stream specific properties
        list_item.setProperty('IsLive', 'true')
        list_item.setContentLookup(False)
        list_item.setPath(url)
        
        xbmcplugin.setResolvedUrl(HANDLE, True, list_item)
        return True
        
    except Exception as e:
        log(f"Live stream playback failed: {e}", xbmc.LOGERROR)
        return False

# ... (rest of the code remains the same for list_items, choose_and_play_stream, router functions)
