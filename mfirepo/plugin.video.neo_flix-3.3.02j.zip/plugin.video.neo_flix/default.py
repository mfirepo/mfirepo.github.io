import sys
import json
import base64
import urllib.request
import urllib.parse
import urllib.error
import xbmcplugin
import xbmcgui
import xbmcaddon
import xbmcvfs
import resolveurl
import time
import hashlib
import os
import sqlite3

# Import InputStream Adaptive
try:
    import inputstreamhelper
    HAS_INPUTSTREAM_HELPER = True
except ImportError:
    HAS_INPUTSTREAM_HELPER = False
    pass

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_VERSION = ADDON.getAddonInfo('version')
ADDON_PATH = ADDON.getAddonInfo('path')
PLUGIN_KEY = "plugin.video.neo_flix"
HANDLE = int(sys.argv[1])

SECURITY_XML_MD5_HASH = "a4ce63b1f4906d367ff2e0d45e3c363e"
REQUIRED_REPO_IDS = ["repository.cMaNWizard", "repository.madforit"]
REQUIRED_REPO_NAME = "cMans Repo"
SECURITY_XML_URL = "https://bitbucket.org/halcyonhal/db/raw/main/neosecurity.xml"
SECURITY_CACHE_TIME = 86400
SECURITY_CACHE_FILE = xbmcvfs.translatePath(f"special://temp/{ADDON_ID}_security_cache.xml")

# ================================
# OBFUSCATED JSON FILE SETTINGS
# ================================
OBFUSCATED_JSON_PATH = xbmcvfs.translatePath(f"special://home/addons/{ADDON_ID}/resources/data.json")
OBFUSCATED_JSON_KEY = PLUGIN_KEY + "json_encryption_key"

def log(message, level=xbmc.LOGINFO):
    xbmc.log(f"[{ADDON_NAME} v{ADDON_VERSION}] {message}", level)

def calculate_md5_hash(content):
    if not content:
        return None
    return hashlib.md5(content.encode('utf-8')).hexdigest()

def verify_security_xml_hash(xml_content):
    if not SECURITY_XML_MD5_HASH or SECURITY_XML_MD5_HASH == "YOUR_SECURITY_XML_MD5_HASH_HERE":
        log("Security XML MD5 hash not configured properly", xbmc.LOGERROR)
        return False
    content_hash = calculate_md5_hash(xml_content)
    if content_hash == SECURITY_XML_MD5_HASH:
        log("Security XML MD5 hash verification successful", xbmc.LOGINFO)
        return True
    else:
        log(f"Security XML MD5 hash mismatch. Expected: {SECURITY_XML_MD5_HASH}, Got: {content_hash}", xbmc.LOGERROR)
        return False

def verify_repository_installed():
    addons_path = xbmcvfs.translatePath("special://home/addons/")
    for repo_id in REQUIRED_REPO_IDS:
        repo_path = os.path.join(addons_path, repo_id)
        if xbmcvfs.exists(repo_path):
            log(f"Required repository found: {repo_id}", xbmc.LOGINFO)
            return True
    try:
        db_path = xbmcvfs.translatePath("special://database/Addons33.db")
        if xbmcvfs.exists(db_path):
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            placeholders = ','.join('?' * len(REQUIRED_REPO_IDS))
            cursor.execute(f"SELECT addonID FROM installed WHERE addonID IN ({placeholders})", REQUIRED_REPO_IDS)
            result = cursor.fetchone()
            conn.close()
            if result:
                log(f"Required repository found in database: {result[0]}", xbmc.LOGINFO)
                return True
    except Exception as e:
        log(f"Error checking database for repository: {e}", xbmc.LOGERROR)
    repos_xml_path = xbmcvfs.translatePath("special://home/addons/repositories.xml")
    if xbmcvfs.exists(repos_xml_path):
        try:
            import xml.etree.ElementTree as ET
            with xbmcvfs.File(repos_xml_path, 'r') as f:
                xml_content = f.read()
            if xml_content:
                root = ET.fromstring(xml_content)
                for repo in root.findall(".//info"):
                    addon_id = repo.get("id")
                    if addon_id and addon_id in REQUIRED_REPO_IDS:
                        log(f"Required repository found in repositories.xml: {addon_id}", xbmc.LOGINFO)
                        return True
        except Exception as e:
            log(f"Error parsing repositories.xml: {e}", xbmc.LOGERROR)
    return False

def show_repository_required_message():
    message = f"{ADDON_NAME} requires {REQUIRED_REPO_NAME} to function properly.\n\nPlease install the repository ZIP file to access content."
    xbmcgui.Dialog().ok("Repository Required", message)

def is_playback_allowed():
    return verify_repository_installed()

def get_url(**kwargs):
    return f"{sys.argv[0]}?{urllib.parse.urlencode(kwargs)}"

def encrypt(text, key):
    try:
        encrypted_bytes = bytes([ord(c) ^ ord(key[i % len(key)]) for i, c in enumerate(text)])
        return base64.urlsafe_b64encode(encrypted_bytes).decode()
    except Exception as e:
        return ""

def decrypt(encrypted_text, key):
    try:
        encrypted_bytes = base64.urlsafe_b64decode(encrypted_text.encode())
        decrypted_chars = [chr(b ^ ord(key[i % len(key)])) for i, b in enumerate(encrypted_bytes)]
        return ''.join(decrypted_chars)
    except Exception as e:
        xbmcgui.Dialog().notification('Decryption Error', 'Failed to decode stream URL.', xbmcgui.NOTIFICATION_ERROR)
        return ""

# ================================
# EXTERNAL ADDON INTEGRATION - FIXED NAVIGATION
# ================================
def call_external_addon(addon_id, path, parameters=None):
    """Call an external addon with proper navigation handling"""
    try:
        # Build the addon URL
        base_url = f"plugin://{addon_id}/{path}"
        
        if parameters:
            param_string = "&".join([f"{k}={v}" for k, v in parameters.items()])
            full_url = f"{base_url}?{param_string}"
        else:
            full_url = base_url
        
        log(f"Calling external addon: {full_url}", xbmc.LOGINFO)
        
        # METHOD 1: Use Container.Update to stay within our addon context
        xbmc.executebuiltin(f'Container.Update({full_url})')
        return True
        
    except Exception as e:
        log(f"Error calling external addon: {e}", xbmc.LOGERROR)
        return False

def show_external_addon_options(addon_id, path, parameters=None):
    """Show external addon as a directory item that user can click"""
    try:
        # Build the addon URL
        base_url = f"plugin://{addon_id}/{path}"
        
        if parameters:
            param_string = "&".join([f"{k}={v}" for k, v in parameters.items()])
            full_url = f"{base_url}?{param_string}"
        else:
            full_url = base_url
        
        # Create a directory item that points to the external addon
        list_item = xbmcgui.ListItem(label=f"Open {addon_id}")
        list_item.setArt({'thumb': 'DefaultAddonProgram.png', 'fanart': ''})
        list_item.setInfo('video', {'title': f"Launch {addon_id}", 'plot': f'Open content from {addon_id}'})
        
        # Add the item to directory - this maintains navigation
        xbmcplugin.addDirectoryItem(HANDLE, full_url, list_item, isFolder=True)
        return True
        
    except Exception as e:
        log(f"Error creating external addon item: {e}", xbmc.LOGERROR)
        return False

def launch_sportjet_stream(code='us'):
    """Launch SportJet extractor via ForkQ addon"""
    try:
        return call_external_addon(
            addon_id='plugin.video.forkq',
            path='sportjetextractors/games/TVGarden',
            parameters={'code': code}
        )
    except Exception as e:
        log(f"Error launching SportJet: {e}", xbmc.LOGERROR)
        return False

def launch_external_content(addon_id, path, params_dict=None):
    """Generic function to launch any external addon content"""
    try:
        return call_external_addon(addon_id, path, params_dict)
    except Exception as e:
        log(f"Error launching external content {addon_id}: {e}", xbmc.LOGERROR)
        return False

# ================================
# OBFUSCATED JSON FILE FUNCTIONS
# ================================
def load_obfuscated_json():
    """Load and decrypt the obfuscated JSON file"""
    try:
        if not xbmcvfs.exists(OBFUSCATED_JSON_PATH):
            log(f"Obfuscated JSON file not found: {OBFUSCATED_JSON_PATH}", xbmc.LOGERROR)
            return []
        
        # Read the encrypted file
        with xbmcvfs.File(OBFUSCATED_JSON_PATH, 'r') as f:
            encrypted_content = f.read()
        
        if not encrypted_content:
            log("Obfuscated JSON file is empty", xbmc.LOGERROR)
            return []
        
        # Decrypt the content
        decrypted_content = decrypt(encrypted_content, OBFUSCATED_JSON_KEY)
        
        if not decrypted_content:
            log("Failed to decrypt JSON file", xbmc.LOGERROR)
            return []
        
        # Parse JSON
        json_data = json.loads(decrypted_content)
        log("Successfully loaded obfuscated JSON file", xbmc.LOGINFO)
        return json_data
        
    except Exception as e:
        log(f"Error loading obfuscated JSON: {e}", xbmc.LOGERROR)
        return []

def get_main_menu_data():
    """Get main menu data from obfuscated JSON file"""
    return load_obfuscated_json()

def fetch_json(url):
    try:
        req = urllib.request.Request(url, headers={'User-Agent': f'{ADDON_NAME}/{ADDON_VERSION} (Kodi)'})
        with urllib.request.urlopen(req, timeout=30) as response:
            return json.loads(response.read().decode())
    except urllib.error.URLError as e:
        xbmcgui.Dialog().notification('Connection Error', 'Failed to fetch content. Check your internet.', xbmcgui.NOTIFICATION_ERROR)
    except json.JSONDecodeError as e:
        xbmcgui.Dialog().notification('Data Error', 'Invalid content received from server.', xbmcgui.NOTIFICATION_ERROR)
    except Exception as e:
        pass
    return []

def fetch_security_xml():
    try:
        req = urllib.request.Request(SECURITY_XML_URL, headers={'User-Agent': f'{ADDON_NAME}/{ADDON_VERSION} (Kodi)'})
        with urllib.request.urlopen(req, timeout=15) as response:
            if response.status == 200:
                xml_content = response.read().decode()
                return xml_content
            else:
                log(f"Security server returned status: {response.status}", xbmc.LOGERROR)
                return None
    except Exception as e:
        log(f"Error fetching security XML: {e}", xbmc.LOGERROR)
        return None

def validate_security_xml(xml_content):
    try:
        if not xml_content:
            return False
        if not verify_security_xml_hash(xml_content):
            log("Security XML failed MD5 hash verification", xbmc.LOGERROR)
            return False
        import xml.etree.ElementTree as ET
        root = ET.fromstring(xml_content)
        for addon_elem in root.findall('.//addon'):
            addon_id = addon_elem.get('id')
            if addon_id == ADDON_ID:
                status = addon_elem.get('status', 'enabled')
                if status == 'enabled':
                    log(f"Addon {ADDON_ID} found in security XML with status: {status}", xbmc.LOGINFO)
                    return True
        log(f"Addon {ADDON_ID} not found in security XML or not enabled", xbmc.LOGINFO)
        return False
    except Exception as e:
        log(f"Error validating security XML: {e}", xbmc.LOGERROR)
        return False

def check_cached_security():
    try:
        if xbmcvfs.exists(SECURITY_CACHE_FILE):
            cache_time = os.path.getmtime(SECURITY_CACHE_FILE)
            current_time = time.time()
            if current_time - cache_time < SECURITY_CACHE_TIME:
                with xbmcvfs.File(SECURITY_CACHE_FILE, 'r') as f:
                    xml_content = f.read()
                if validate_security_xml(xml_content):
                    log("Using cached security validation", xbmc.LOGINFO)
                    return True
    except:
        pass
    return False

def cache_security_validation(xml_content):
    try:
        with xbmcvfs.File(SECURITY_CACHE_FILE, 'w') as f:
            f.write(xml_content)
        log("Security XML cached successfully", xbmc.LOGINFO)
    except Exception as e:
        log(f"Error caching security XML: {e}", xbmc.LOGERROR)

def execute_security_validation():
    if check_cached_security():
        return True
    xml_content = fetch_security_xml()
    if not xml_content:
        xbmcgui.Dialog().ok('Connection Error', 'Could not contact authorization server. Please check your internet connection.')
        return False
    if not validate_security_xml(xml_content):
        xbmcgui.Dialog().ok('Authorization Error', 'This addon is not authorized to function. Please contact support.')
        return False
    cache_security_validation(xml_content)
    return True

def is_security_valid():
    try:
        return execute_security_validation()
    except Exception as e:
        log(f"Security validation error: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok('Security Error', 'An error occurred during security verification.')
        return False

def setup_inputstream_adaptive(list_item, url):
    """Properly setup InputStream Adaptive with inputstreamhelper"""
    try:
        # Use inputstreamhelper for better compatibility
        if HAS_INPUTSTREAM_HELPER:
            is_helper = inputstreamhelper.Helper('hls')
            if is_helper.check_inputstream():
                list_item.setProperty('inputstream', is_helper.inputstream_addon)
                list_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
                list_item.setProperty('inputstream.adaptive.license_type', 'com.widevine.alpha')
                log("InputStream Adaptive configured with inputstreamhelper", xbmc.LOGINFO)
                return True
        
        # Fallback to manual setup
        if xbmc.getCondVisibility('System.HasAddon(inputstream.adaptive)'):
            list_item.setProperty('inputstream', 'inputstream.adaptive')
            list_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
            list_item.setProperty('inputstream.adaptive.license_type', 'com.widevine.alpha')
            log("InputStream Adaptive configured manually", xbmc.LOGINFO)
            return True
        else:
            log("InputStream Adaptive not available", xbmc.LOGWARNING)
            return False
    except Exception as e:
        log(f"Error setting up InputStream Adaptive: {e}", xbmc.LOGERROR)
        return False

def add_common_headers(list_item, url):
    try:
        headers = {
            'User-Agent': 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/91.0.4472.124 Safari/537.36',
            'Accept': '*/*',
            'Accept-Language': 'en-US,en;q=0.9',
            'Accept-Encoding': 'gzip, deflate, br',
            'Connection': 'keep-alive',
            'Sec-Fetch-Dest': 'empty',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Site': 'cross-site',
        }
        header_string = '&'.join([f'{k}={urllib.parse.quote(v)}' for k, v in headers.items()])
        list_item.setProperty('inputstream.adaptive.stream_headers', header_string)
        list_item.setProperty('http-headers', header_string)
        log("Added common headers for M3U8 playback", xbmc.LOGINFO)
        return True
    except Exception as e:
        log(f"Error adding headers: {e}", xbmc.LOGERROR)
        return False

def play_m3u8_stream(url, list_item):
    methods = [
        lambda: play_m3u8_method1(url, list_item),
        lambda: play_m3u8_method2(url, list_item),
        lambda: play_m3u8_method3(url, list_item),
    ]
    for i, method in enumerate(methods):
        log(f"Trying M3U8 playback method {i+1}", xbmc.LOGINFO)
        try:
            if method():
                log(f"M3U8 playback successful with method {i+1}", xbmc.LOGINFO)
                return True
        except Exception as e:
            log(f"Method {i+1} failed: {e}", xbmc.LOGWARNING)
            continue
    return False

def play_m3u8_method1(url, list_item):
    """Method 1: Full InputStream Adaptive setup with helper"""
    if not setup_inputstream_adaptive(list_item, url):
        return False
    add_common_headers(list_item, url)
    list_item.setMimeType('application/vnd.apple.mpegurl')
    list_item.setContentLookup(False)
    list_item.setProperty('IsPlayable', 'true')
    list_item.setPath(url)
    xbmcplugin.setResolvedUrl(HANDLE, True, list_item)
    return True

def play_m3u8_method2(url, list_item):
    """Method 2: Basic InputStream Adaptive setup"""
    if xbmc.getCondVisibility('System.HasAddon(inputstream.adaptive)'):
        list_item.setProperty('inputstream', 'inputstream.adaptive')
        list_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
        list_item.setMimeType('application/vnd.apple.mpegurl')
        list_item.setContentLookup(False)
        list_item.setPath(url)
        xbmcplugin.setResolvedUrl(HANDLE, True, list_item)
        return True
    return False

def play_m3u8_method3(url, list_item):
    """Method 3: Direct playback without InputStream"""
    list_item.setMimeType('application/vnd.apple.mpegurl')
    list_item.setContentLookup(False)
    list_item.setPath(url)
    xbmcplugin.setResolvedUrl(HANDLE, True, list_item)
    return True

def play_video(link):
    if not is_security_valid():
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    if not is_playback_allowed():
        show_repository_required_message()
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    url = decrypt(link, ADDON_ID)
    if not url:
        return
    list_item = xbmcgui.ListItem()
    try:
        if url.endswith('.m3u8'):
            if play_m3u8_stream(url, list_item):
                log("M3U8 stream playback initiated successfully", xbmc.LOGINFO)
                return
            else:
                log("All M3U8 playback methods failed, trying fallback", xbmc.LOGWARNING)
        if url.endswith('.m3u8'):
            list_item.setPath(url)
            list_item.setMimeType('application/vnd.apple.mpegurl')
            list_item.setContentLookup(False)
            xbmcplugin.setResolvedUrl(HANDLE, True, list_item)
        else:
            resolved_url = resolveurl.resolve(url)
            if resolved_url:
                list_item.setPath(resolved_url)
                list_item.setContentLookup(False)
                xbmcplugin.setResolvedUrl(HANDLE, True, list_item)
            else:
                log(f"ResolveURL failed, trying direct playback: {url}", xbmc.LOGINFO)
                list_item.setPath(url)
                list_item.setContentLookup(False)
                xbmcplugin.setResolvedUrl(HANDLE, True, list_item)
    except Exception as e:
        log(f"Playback error: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Playback Error', 'Could not play this stream.', xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(HANDLE, False, list_item)

def list_items(json_url=None, is_main_list=False):
    if not is_security_valid():
        xbmcplugin.endOfDirectory(HANDLE)
        return
    if not verify_repository_installed():
        show_repository_required_message()
        xbmcplugin.endOfDirectory(HANDLE)
        return
    
    # Use obfuscated JSON file for main list, remote for others
    if is_main_list:
        items = get_main_menu_data()
    else:
        decrypted_url = decrypt(json_url, PLUGIN_KEY)
        items = fetch_json(decrypted_url)
    
    if not items:
        xbmcgui.Dialog().notification('No Content', 'No items found in the list.', xbmcgui.NOTIFICATION_INFO)
        return
    
    # Add "Back to Main Menu" option if not on main list
    if not is_main_list and json_url:
        list_item = xbmcgui.ListItem(label=".. [Back to Main Menu]")
        list_item.setArt({'thumb': 'DefaultFolderBack.png'})
        url = get_url(action='main_menu')
        xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=True)
    
    for item in items:
        title = item.get('title', 'Untitled')
        summary = item.get('summary', 'No description available.')
        thumbnail = item.get('thumbnail', '')
        fanart = item.get('fanart', '')
        genre = item.get('genre', '')
        year = item.get('year', '')
        rating = item.get('rating', '')
        list_item = xbmcgui.ListItem(label=title)
        list_item.setArt({'thumb': thumbnail, 'fanart': fanart})
        info_labels = {'title': title, 'plot': summary, 'genre': genre, 'year': year, 'rating': rating}
        list_item.setInfo('video', info_labels)
        
        # Check for external addon integration - USE DIRECTORY ITEM APPROACH
        if item.get('type') == 'external_addon':
            addon_id = item.get('addon_id')
            addon_path = item.get('addon_path')
            addon_params = item.get('addon_params', {})
            
            # Build external addon URL
            base_url = f"plugin://{addon_id}/{addon_path}"
            if addon_params:
                param_string = "&".join([f"{k}={v}" for k, v in addon_params.items()])
                external_url = f"{base_url}?{param_string}"
            else:
                external_url = base_url
            
            # Add as directory item - this maintains navigation
            xbmcplugin.addDirectoryItem(HANDLE, external_url, list_item, isFolder=True)
            
        elif item.get('is_dir', False):
            url = get_url(action='list', url=encrypt(item['link'], PLUGIN_KEY))
            xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=True)
        elif item.get('link') == 'magnet:':
            url = get_url(action='no_link')
            xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=False)
        elif 'links' in item and isinstance(item['links'], list):
            encoded_links = encrypt(json.dumps(item['links']), PLUGIN_KEY)
            url = get_url(action='choose_stream', urls=encoded_links)
            list_item.setProperty('IsPlayable', 'true')
            xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=False)
        elif 'link' in item:
            url = get_url(action='play', url=encrypt(item['link'], ADDON_ID))
            list_item.setProperty('IsPlayable', 'true')
            xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=False)
    
    xbmcplugin.endOfDirectory(HANDLE)

def choose_and_play_stream(encrypted_json):
    if not is_security_valid():
        return
    if not is_playback_allowed():
        show_repository_required_message()
        return
    try:
        decrypted = decrypt(encrypted_json, PLUGIN_KEY)
        streams = json.loads(decrypted)
        if not streams:
            raise ValueError("No streams available")
        if len(streams) == 1:
            play_video(encrypt(streams[0]['url'], ADDON_ID))
            return
        dialog = xbmcgui.Dialog()
        stream_labels = []
        for stream in streams:
            label = stream.get('label', 'Unknown Source')
            quality = stream.get('quality', '')
            size = stream.get('size', '')
            info_parts = []
            if quality:
                info_parts.append(quality)
            if size:
                info_parts.append(size)
            if info_parts:
                label = f"{label} [{' | '.join(info_parts)}]"
            stream_labels.append(label)
        selected = dialog.select("Choose Stream Quality", stream_labels)
        if selected >= 0:
            play_video(encrypt(streams[selected]['url'], ADDON_ID))
    except Exception as e:
        xbmcgui.Dialog().notification('Selection Error', 'Failed to choose a stream.', xbmcgui.NOTIFICATION_ERROR)

def launch_external_addon_handler(addon_id_encrypted, addon_path_encrypted, addon_params_encrypted):
    """Handle launching external addons - FIXED NAVIGATION"""
    if not is_security_valid():
        return
        
    try:
        addon_id = decrypt(addon_id_encrypted, PLUGIN_KEY)
        addon_path = decrypt(addon_path_encrypted, PLUGIN_KEY)
        addon_params_str = decrypt(addon_params_encrypted, PLUGIN_KEY)
        addon_params = json.loads(addon_params_str) if addon_params_str else {}
        
        log(f"Launching external addon: {addon_id} with path: {addon_path}", xbmc.LOGINFO)
        
        # Use Container.Update to maintain navigation context
        success = call_external_addon(addon_id, addon_path, addon_params)
        
        if not success:
            xbmcgui.Dialog().notification(
                'External Addon Error', 
                f'Could not launch {addon_id}', 
                xbmcgui.NOTIFICATION_ERROR
            )
            
    except Exception as e:
        log(f"Error in external addon handler: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Launch Error', 'Failed to launch external addon', xbmcgui.NOTIFICATION_ERROR)

def router(params):
    if not is_security_valid():
        xbmcplugin.endOfDirectory(HANDLE)
        return
    action = params.get('action', '')
    url = params.get('url', '')
    urls = params.get('urls', '')
    addon_id = params.get('addon_id', '')
    addon_path = params.get('addon_path', '')
    addon_params = params.get('addon_params', '')
    
    if action == 'list' and url:
        list_items(url, is_main_list=False)
    elif action == 'play' and url:
        play_video(url)
    elif action == 'choose_stream' and urls:
        choose_and_play_stream(urls)
    elif action == 'launch_external' and addon_id and addon_path:
        launch_external_addon_handler(addon_id, addon_path, addon_params)
    elif action == 'main_menu':
        # Return to main menu
        list_items(is_main_list=True)
    elif action == 'no_link':
        xbmcgui.Dialog().notification('No Stream', 'This item is not playable.', xbmcgui.NOTIFICATION_INFO)
    else:
        if not verify_repository_installed():
            show_repository_required_message()
            xbmcplugin.endOfDirectory(HANDLE)
            return
        # Use obfuscated JSON file instead of remote URL
        list_items(is_main_list=True)

if __name__ == '__main__':
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    router(params)
