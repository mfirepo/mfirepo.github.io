import xbmcaddon
import xbmcvfs
import sys

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_VERSION = ADDON.getAddonInfo('version')
ADDON_PATH = ADDON.getAddonInfo('path')
PLUGIN_KEY = "plugin.video.forkq"
HANDLE = int(sys.argv[1])

# Security settings
SECURITY_XML_MD5_HASH = "35e2d9d982964d3442708c34e4012c45"
REQUIRED_REPO_IDS = ["repository.cMaNWizard", "repository.madforit"]
REQUIRED_REPO_NAME = "cMans Repo"
SECURITY_XML_URL = "https://bitbucket.org/halcyonhal/db/raw/main/4qsecurity.xml"
SECURITY_CACHE_TIME = 86400

# Cache settings
SUBLIST_CACHE_TIME = 86400
SUBLIST_CACHE_DIR = xbmcvfs.translatePath(f"special://temp/{ADDON_ID}_cache/")
SECURITY_CACHE_FILE = xbmcvfs.translatePath(f"special://temp/{ADDON_ID}_security_cache.xml")
LOCAL_JSON_PATH = xbmcvfs.translatePath(f"special://home/addons/{ADDON_ID}/resources/data.json")

# Paths
ADDON_ICON = xbmcvfs.translatePath(f"special://home/addons/{ADDON_ID}/icon.png")
ADDON_FANART = xbmcvfs.translatePath(f"special://home/addons/{ADDON_ID}/fanart.jpg")

# Encryption
OBFUSCATED_JSON_KEY = PLUGIN_KEY + "json_encryption_key"
