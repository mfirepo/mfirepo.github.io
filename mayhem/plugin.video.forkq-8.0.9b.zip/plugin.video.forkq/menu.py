import json
import xbmcplugin
import xbmcgui
import xbmc
import xbmcvfs
import urllib.request
import sys
from config import (
    ADDON_ICON, ADDON_FANART, ADDON_NAME, ADDON_VERSION,
    LOCAL_JSON_PATH, OBFUSCATED_JSON_KEY, PLUGIN_KEY, HANDLE,
    ADDON_ID  # ADD THIS IMPORT
)
from utils import log, get_url
from encryption import encrypt, decrypt
from cache import CacheManager
from security import SecurityManager

class MenuManager:
    def __init__(self):
        self.cache_manager = CacheManager()
        self.security_manager = SecurityManager()
        self.handle = HANDLE
    
    def load_local_json(self):
        """Load JSON data from local file with XOR encryption"""
        try:
            if not xbmcvfs.exists(LOCAL_JSON_PATH):
                log(f"Local JSON file not found: {LOCAL_JSON_PATH}", xbmc.LOGERROR)
                return []
                
            with xbmcvfs.File(LOCAL_JSON_PATH, 'r') as f:
                encrypted_content = f.read()
                
            if not encrypted_content:
                log("Local JSON file is empty", xbmc.LOGERROR)
                return []
                
            decrypted_content = decrypt(encrypted_content, OBFUSCATED_JSON_KEY)
            if decrypted_content:
                try:
                    data = json.loads(decrypted_content)
                    log(f"Successfully loaded {len(data)} menu items from local JSON (XOR decrypted)")
                    return data
                except json.JSONDecodeError:
                    log("Failed to parse decrypted JSON content", xbmc.LOGERROR)
                    return []
            else:
                try:
                    data = json.loads(encrypted_content)
                    log(f"Successfully loaded {len(data)} menu items from local JSON (plain)")
                    return data
                except json.JSONDecodeError:
                    log("Failed to parse JSON content as either encrypted or plain", xbmc.LOGERROR)
                    return []
                    
        except Exception as e:
            log(f"Error loading local JSON: {str(e)}", xbmc.LOGERROR)
            return []
    
    def get_main_menu_data(self):
        """Get main menu data and add Clear Cache option"""
        menu_data = self.load_local_json()
        
        clear_cache_item = {
            'title': '[COLOR yellow]Clear Cache[/COLOR]',
            'summary': 'Clear all temporary cache files to free up space and resolve potential issues',
            'thumbnail': ADDON_ICON,
            'fanart': ADDON_FANART,
            'type': 'clear_cache'
        }
        
        if menu_data:
            menu_data.append(clear_cache_item)
        else:
            menu_data = [clear_cache_item]
            
        return menu_data
    
    def fetch_json(self, url):
        """Fetch JSON from remote URL for submenus with caching"""
        cached_data = self.cache_manager.get_cached_sublist(url)
        if cached_data is not None:
            return cached_data
            
        try:
            log(f"Fetching JSON from: {url}")
            req = urllib.request.Request(url, headers={
                'User-Agent': f'{ADDON_NAME}/{ADDON_VERSION} (Kodi)',
                'Accept': 'application/json'
            })
            with urllib.request.urlopen(req, timeout=30) as response:
                data = json.loads(response.read().decode())
            
            log(f"Successfully fetched {len(data) if isinstance(data, list) else 'unknown'} items")
            
            self.cache_manager.cache_sublist(url, data)
            return data
            
        except Exception as e:
            log(f"Error fetching JSON from {url}: {str(e)}", xbmc.LOGERROR)
            return []
    
    def call_external_addon(self, addon_id, path, parameters=None):
        try:
            base_url = f"plugin://{addon_id}/{path}"
            if parameters:
                param_string = "&".join([f"{k}={v}" for k, v in parameters.items()])
                full_url = f"{base_url}?{param_string}"
            else:
                full_url = base_url
            xbmc.executebuiltin(f'Container.Update({full_url})')
            return True
        except Exception as e:
            log(f"Error calling external addon: {str(e)}", xbmc.LOGERROR)
            return False
    
    def launch_sportjet_stream(self, code='us'):
        try:
            return self.call_external_addon('plugin.video.forkq', 'sportjetextractors/games/TVGarden', {'code': code})
        except Exception as e:
            log(f"Error launching sportjet stream: {str(e)}", xbmc.LOGERROR)
            return False
    
    def list_items(self, json_url=None, is_main_list=False):
        if not self.security_manager.is_security_valid():
            xbmcplugin.endOfDirectory(self.handle)
            return
        if not self.security_manager.verify_repository_installed():
            self.security_manager.show_repository_required_message()
            xbmcplugin.endOfDirectory(self.handle)
            return
            
        if is_main_list:
            log("Loading main menu data from local JSON...")
            items = self.get_main_menu_data()
        else:
            decrypted_url = decrypt(json_url, PLUGIN_KEY)
            log(f"Loading submenu from: {decrypted_url}")
            items = self.fetch_json(decrypted_url)
            
        if not items:
            log("No items found to display")
            xbmcgui.Dialog().notification('No Content', 'No content available at this time.', xbmcgui.NOTIFICATION_INFO)
            xbmcplugin.endOfDirectory(self.handle)
            return
            
        log(f"Displaying {len(items)} items")
        
        for item in items:
            title = item.get('title', 'Untitled')
            summary = item.get('summary', 'No description available.')
            thumbnail = item.get('thumbnail', ADDON_ICON)
            fanart = item.get('fanart', ADDON_FANART)
            list_item = xbmcgui.ListItem(label=title)
            list_item.setArt({
                'thumb': thumbnail,
                'icon': thumbnail,
                'fanart': fanart
            })
            info_labels = {'title': title, 'plot': summary, 'genre': item.get('genre', ''), 'year': item.get('year', ''), 'rating': item.get('rating', '')}
            list_item.setInfo('video', info_labels)
            
            if item.get('type') == 'clear_cache':
                url = get_url(action='clear_cache')
                list_item.setProperty('IsPlayable', 'false')
                xbmcplugin.addDirectoryItem(self.handle, url, list_item, isFolder=False)
            elif item.get('type') == 'external_addon':
                addon_id = item.get('addon_id')
                addon_path = item.get('addon_path')
                addon_params = item.get('addon_params', {})
                base_url = f"plugin://{addon_id}/{addon_path}"
                if addon_params:
                    param_string = "&".join([f"{k}={v}" for k, v in addon_params.items()])
                    external_url = f"{base_url}?{param_string}"
                else:
                    external_url = base_url
                xbmcplugin.addDirectoryItem(self.handle, external_url, list_item, isFolder=True)
            elif item.get('is_dir', False):
                url = get_url(action='list', url=encrypt(item['link'], PLUGIN_KEY))
                xbmcplugin.addDirectoryItem(self.handle, url, list_item, isFolder=True)
            elif item.get('link') == 'magnet:':
                url = get_url(action='no_link')
                xbmcplugin.addDirectoryItem(self.handle, url, list_item, isFolder=False)
            elif 'links' in item and isinstance(item['links'], list):
                encoded_links = encrypt(json.dumps(item['links']), PLUGIN_KEY)
                url = get_url(action='choose_stream', urls=encoded_links)
                list_item.setProperty('IsPlayable', 'true')
                xbmcplugin.addDirectoryItem(self.handle, url, list_item, isFolder=False)
            elif 'link' in item:
                url = get_url(action='play', url=encrypt(item['link'], ADDON_ID))
                list_item.setProperty('IsPlayable', 'true')
                xbmcplugin.addDirectoryItem(self.handle, url, list_item, isFolder=False)
            else:
                log(f"Item '{title}' has no valid action type")
                
        xbmcplugin.endOfDirectory(self.handle)
    
    def launch_external_addon_handler(self, addon_id_encrypted, addon_path_encrypted, addon_params_encrypted):
        if not self.security_manager.is_security_valid():
            return
        try:
            addon_id = decrypt(addon_id_encrypted, PLUGIN_KEY)
            addon_path = decrypt(addon_path_encrypted, PLUGIN_KEY)
            addon_params_str = decrypt(addon_params_encrypted, PLUGIN_KEY)
            addon_params = json.loads(addon_params_str) if addon_params_str else {}
            success = self.call_external_addon(addon_id, addon_path, addon_params)
            if not success:
                xbmcgui.Dialog().notification('External Addon Error', f'Could not launch {addon_id}', xbmcgui.NOTIFICATION_ERROR)
        except Exception as e:
            log(f"Error launching external addon: {str(e)}", xbmc.LOGERROR)
            xbmcgui.Dialog().notification('Launch Error', 'Failed to launch external addon', xbmcgui.NOTIFICATION_ERROR)
