import time
import urllib.request
import urllib.parse
import xbmcplugin
import xbmcgui
import xbmc
import xbmcvfs
import resolveurl
import re
import json
from config import ADDON_ID, PLUGIN_KEY, HANDLE, ADDON_NAME, ADDON_VERSION
from utils import log
from encryption import decrypt, encrypt
from security import SecurityManager

class PlaybackManager:
    def __init__(self):
        self.security_manager = SecurityManager()
        self.user_agents = [
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36',
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0',
            'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
            'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
        ]
    
    def get_rotated_user_agent(self):
        return self.user_agents[int(time.time()) % len(self.user_agents)]
    
    def setup_robust_inputstream(self, list_item, url):
        list_item.setProperty('inputstream', 'inputstream.adaptive')
        list_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
        list_item.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')
        list_item.setProperty('inputstream.adaptive.license_flags', 'persistent_storage')
        list_item.setProperty('inputstream.adaptive.license_type', 'com.widevine.alpha')
        list_item.setProperty('inputstream.adaptive.connection_timeout', '60')
        list_item.setProperty('inputstream.adaptive.manifest_timeout', '60')
        list_item.setProperty('inputstream.adaptive.live_delay', '3')
        list_item.setProperty('inputstream.adaptive.max_bandwidth', '12000000')
        list_item.setProperty('inputstream.adaptive.min_bandwidth', '500000')
        list_item.setProperty('inputstream.adaptive.max_resolution', '1080p')
        list_item.setProperty('inputstream.adaptive.network_caching', '20000')
        list_item.setProperty('inputstream.adaptive.segment_download_retries', '10')
        list_item.setProperty('inputstream.adaptive.segment_download_timeout', '45')
        list_item.setProperty('inputstream.adaptive.segment_download_retry_wait', '5')
        list_item.setProperty('inputstream.adaptive.max_segment_count', '50')
        list_item.setProperty('inputstream.adaptive.play_timeshift_buffer', 'true')
        list_item.setProperty('inputstream.adaptive.ignore_manifest_segment_timestamps', 'true')
        return True
    
    def extract_m3u8_segments(self, m3u8_content):
        segments = []
        lines = m3u8_content.split('\n')
        for line in lines:
            if line.startswith('http') and '.ts' in line:
                segments.append(line.strip())
        return segments
    
    def get_refreshed_stream(self, base_url, max_retries=5):
        for attempt in range(max_retries):
            try:
                timestamp = int(time.time())
                user_agent = self.get_rotated_user_agent()
                
                refreshed_url = f"{base_url}{'&' if '?' in base_url else '?'}_t={timestamp}&_={timestamp}"
                
                req = urllib.request.Request(refreshed_url, headers={
                    'User-Agent': user_agent,
                    'Accept': '*/*',
                    'Accept-Language': 'en-US,en;q=0.9',
                    'Accept-Encoding': 'identity',
                    'Connection': 'keep-alive',
                    'Cache-Control': 'no-cache',
                    'Pragma': 'no-cache'
                })
                
                with urllib.request.urlopen(req, timeout=15) as response:
                    if response.status == 200:
                        content = response.read().decode('utf-8')
                        if '#EXTM3U' in content:
                            log(f"Stream refresh successful - attempt {attempt + 1}")
                            return refreshed_url
                        else:
                            log(f"Invalid M3U8 content received")
                            
            except Exception as e:
                log(f"Stream refresh attempt {attempt + 1} failed: {str(e)}")
                time.sleep(3)
        
        log("All stream refresh attempts failed")
        return base_url
    
    def check_stream_health(self, url):
        try:
            req = urllib.request.Request(url, headers={
                'User-Agent': self.get_rotated_user_agent(),
                'Accept': '*/*',
                'Cache-Control': 'no-cache'
            })
            with urllib.request.urlopen(req, timeout=15) as response:
                content = response.read().decode('utf-8')
                if '#EXTM3U' in content and '#EXTINF' in content:
                    segments = self.extract_m3u8_segments(content)
                    log(f"Stream health check passed - {len(segments)} segments found")
                    return True
            return False
        except Exception as e:
            log(f"Stream health check failed: {str(e)}")
            return False
    
    def create_robust_headers(self):
        user_agent = self.get_rotated_user_agent()
        return {
            'User-Agent': user_agent,
            'Accept': '*/*',
            'Accept-Language': 'en-US,en;q=0.9',
            'Accept-Encoding': 'identity',
            'Connection': 'keep-alive',
            'Sec-Fetch-Dest': 'empty',
            'Sec-Fetch-Mode': 'cors',
            'Sec-Fetch-Site': 'same-origin',
            'Cache-Control': 'no-cache',
            'Pragma': 'no-cache'
        }
    
    def play_robust_m3u8(self, url, list_item):
        list_item.setMimeType('application/vnd.apple.mpegurl')
        list_item.setContentLookup(False)
        list_item.setProperty('IsPlayable', 'true')
        
        self.setup_robust_inputstream(list_item, url)
        
        headers = self.create_robust_headers()
        header_string = '&'.join([f'{k}={urllib.parse.quote(v)}' for k, v in headers.items()])
        list_item.setProperty('inputstream.adaptive.stream_headers', header_string)
        list_item.setProperty('http-headers', header_string)
        
        list_item.setPath(url)
        xbmcplugin.setResolvedUrl(HANDLE, True, list_item)
        return True
    
    def monitor_playback(self):
        player = xbmc.Player()
        monitor = xbmc.Monitor()
        last_check = time.time()
        
        while not monitor.abortRequested() and player.isPlaying():
            current_time = time.time()
            if current_time - last_check > 30:
                try:
                    playing_file = player.getPlayingFile()
                    if playing_file and '.m3u8' in playing_file:
                        if not self.check_stream_health(playing_file):
                            log("Stream health check failed during playback")
                            return False
                    last_check = current_time
                except:
                    pass
            if monitor.waitForAbort(5):
                break
        return True
    
    def play_video_with_recovery(self, link):
        if not self.security_manager.is_security_valid():
            return
            
        original_url = decrypt(link, ADDON_ID)
        if not original_url:
            return
            
        max_attempts = 3
        for attempt in range(max_attempts):
            try:
                list_item = xbmcgui.ListItem()
                current_url = original_url
                
                if attempt > 0:
                    current_url = self.get_refreshed_stream(original_url)
                    log(f"Playback attempt {attempt + 1} with refreshed URL")
                
                if current_url.endswith('.m3u8'):
                    if self.play_robust_m3u8(current_url, list_item):
                        if self.monitor_playback():
                            log("Playback completed successfully")
                            return True
                        else:
                            log("Playback monitoring detected stream failure")
                            continue
                else:
                    resolved_url = resolveurl.resolve(current_url)
                    if resolved_url:
                        list_item.setPath(resolved_url)
                    else:
                        list_item.setPath(current_url)
                        
                    list_item.setContentLookup(False)
                    xbmcplugin.setResolvedUrl(HANDLE, True, list_item)
                    return True
                    
            except Exception as e:
                log(f"Playback attempt {attempt + 1} failed: {str(e)}")
                if attempt < max_attempts - 1:
                    time.sleep(5)
        
        xbmcgui.Dialog().notification('Playback Error', 'Could not establish stable stream connection', xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
    
    def play_video(self, link):
        if not self.security_manager.is_security_valid():
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
            return
        if not self.security_manager.is_playback_allowed():
            self.security_manager.show_repository_required_message()
            xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
            return
            
        self.play_video_with_recovery(link)
    
    def get_stream_quality_score(self, stream):
        """Calculate quality score for stream based on resolution and audio quality"""
        score = 0
        label = stream.get('label', '').lower()
        quality = stream.get('quality', '').lower()
        size = stream.get('size', '').lower()
        
        # Resolution scoring
        if '4k' in label or '4k' in quality or '2160' in label:
            score += 100
        elif '1080' in label or '1080' in quality or 'fhd' in label:
            score += 80
        elif '720' in label or '720' in quality or 'hd' in label:
            score += 60
        elif '480' in label or '480' in quality or 'sd' in label:
            score += 40
        
        # Audio quality scoring
        if 'dolby' in label or 'dolby' in quality or 'atmos' in label:
            score += 30
        elif 'dts' in label or 'dts' in quality:
            score += 25
        elif '5.1' in label or '5.1' in quality:
            score += 20
        elif 'ac3' in label or 'ac3' in quality:
            score += 15
        
        # Source reliability scoring
        if 'official' in label or 'original' in label:
            score += 25
        elif 'web' in label or 'web-dl' in label:
            score += 20
        elif 'bluray' in label or 'bdrip' in label:
            score += 15
        
        # Size-based scoring (larger files often mean better quality)
        if 'gb' in size or 'gib' in size:
            try:
                size_num = float(re.findall(r'(\d+\.?\d*)\s*(gb|gib)', size)[0][0])
                score += min(size_num * 5, 50)  # Cap at 50 points for size
            except:
                pass
        
        # Penalize cam/ts/screener quality
        if 'cam' in label or 'ts' in label or 'screener' in label or 'tc' in label:
            score -= 50
        
        return max(score, 0)  # Ensure score doesn't go negative
    
    def get_best_stream(self, streams):
        """Select the best stream based on quality score"""
        if not streams:
            return None
        
        scored_streams = []
        for stream in streams:
            score = self.get_stream_quality_score(stream)
            scored_streams.append((score, stream))
        
        # Sort by score descending
        scored_streams.sort(key=lambda x: x[0], reverse=True)
        
        best_score, best_stream = scored_streams[0]
        log(f"Selected best stream: {best_stream.get('label', 'Unknown')} with score: {best_score}")
        
        # Log all stream scores for debugging
        for score, stream in scored_streams:
            log(f"Stream: {stream.get('label', 'Unknown')} - Score: {score}")
        
        return best_stream
    
    def autoplay_best_stream(self, streams):
        """Automatically play the best available stream"""
        if not streams:
            xbmcgui.Dialog().notification('No Streams', 'No streams available', xbmcgui.NOTIFICATION_ERROR)
            return False
        
        best_stream = self.get_best_stream(streams)
        if best_stream:
            stream_url = best_stream.get('url')
            if stream_url:
                log(f"Autoplaying best stream: {best_stream.get('label', 'Unknown')}")
                self.play_video(encrypt(stream_url, ADDON_ID))
                return True
        
        return False
    
    def choose_and_play_stream(self, encrypted_json):
        """Automatically play the best stream without any dialog boxes"""
        if not self.security_manager.is_security_valid():
            return
        if not self.security_manager.is_playback_allowed():
            self.security_manager.show_repository_required_message()
            return
        try:
            decrypted = decrypt(encrypted_json, PLUGIN_KEY)
            streams = json.loads(decrypted)
            if not streams:
                xbmcgui.Dialog().notification('No Streams', 'No streams available', xbmcgui.NOTIFICATION_ERROR)
                return
            
            # Always autoplay the best stream - no dialog boxes
            if len(streams) == 1:
                log("Only one stream available, playing it")
                self.play_video(encrypt(streams[0]['url'], ADDON_ID))
            else:
                log(f"Multiple streams available, autoplaying best quality from {len(streams)} options")
                self.autoplay_best_stream(streams)
                
        except Exception as e:
            log(f"Stream selection error: {str(e)}", xbmc.LOGERROR)
            xbmcgui.Dialog().notification('Selection Error', 'Failed to choose a stream.', xbmcgui.NOTIFICATION_ERROR)
