import sys
import urllib.parse
import xbmc
import xbmcvfs
from config import ADDON_NAME, ADDON_VERSION

def log(message, level=xbmc.LOGINFO):
    xbmc.log(f"[{ADDON_NAME} v{ADDON_VERSION}] {message}", level)

def get_url(**kwargs):
    return f"{sys.argv[0]}?{urllib.parse.urlencode(kwargs)}"

def ensure_directory(path):
    if not xbmcvfs.exists(path):
        xbmcvfs.mkdirs(path)
        return True
    return False
