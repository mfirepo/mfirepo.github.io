import xbmcplugin
import xbmcgui
import xbmc
import sys
from config import HANDLE
from utils import log
from security import SecurityManager
from menu import MenuManager
from playback import PlaybackManager
from cache import CacheManager

class Router:
    def __init__(self):
        self.security_manager = SecurityManager()
        self.menu_manager = MenuManager()
        self.playback_manager = PlaybackManager()
        self.cache_manager = CacheManager()
        self.handle = HANDLE
    
    def route(self, params):
        """Route requests to appropriate handlers with security validation"""
        log(f"Router called with params: {params}")
        
        # Security validation
        if not self.security_manager.is_security_valid():
            log("Security validation failed, ending directory")
            xbmcplugin.endOfDirectory(self.handle)
            return
        
        # Parameter validation
        if not isinstance(params, dict):
            log("Invalid parameters received, using empty dict")
            params = {}
            
        try:
            action = params.get('action', '')
            url = params.get('url', '')
            urls = params.get('urls', '')
            addon_id = params.get('addon_id', '')
            addon_path = params.get('addon_path', '')
            addon_params = params.get('addon_params', '')
            
            # Route to appropriate handler
            if action == 'list' and url:
                log(f"Routing to list items with URL")
                self.menu_manager.list_items(url, is_main_list=False)
            elif action == 'play' and url:
                log(f"Routing to play video")
                self.playback_manager.play_video(url)
            elif action == 'choose_stream' and urls:
                log(f"Routing to choose stream")
                self.playback_manager.choose_and_play_stream(urls)
            elif action == 'launch_external' and addon_id and addon_path:
                log(f"Routing to external addon: {addon_id}")
                self.menu_manager.launch_external_addon_handler(addon_id, addon_path, addon_params)
            elif action == 'clear_cache':
                log("Routing to clear cache")
                self.cache_manager.clear_cache_safe()
                xbmcplugin.endOfDirectory(self.handle, succeeded=False)
            elif action == 'main_menu':
                log("Routing to main menu")
                self.menu_manager.list_items(is_main_list=True)
            elif action == 'no_link':
                log("Showing no link notification")
                xbmcgui.Dialog().notification('No Stream', 'This item is not playable.', xbmcgui.NOTIFICATION_INFO)
            else:
                log("No valid action, showing main menu")
                if not self.security_manager.verify_repository_installed():
                    self.security_manager.show_repository_required_message()
                    xbmcplugin.endOfDirectory(self.handle)
                    return
                self.menu_manager.list_items(is_main_list=True)
                
            log(f"Router successfully completed action: {action or 'main_menu'}")
            
        except Exception as e:
            log(f"Router error: {str(e)}", xbmc.LOGERROR)
            xbmcgui.Dialog().notification('Error', 'Failed to process request', xbmcgui.NOTIFICATION_ERROR)
            xbmcplugin.endOfDirectory(self.handle)
