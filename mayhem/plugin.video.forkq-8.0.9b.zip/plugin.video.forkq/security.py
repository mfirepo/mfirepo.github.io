import os
import time
import sqlite3
import urllib.request
import xbmcgui
import xbmcvfs
import xbmc
import hashlib
import xml.etree.ElementTree as ET
from config import (
    SECURITY_XML_MD5_HASH, REQUIRED_REPO_IDS, REQUIRED_REPO_NAME,
    SECURITY_XML_URL, SECURITY_CACHE_TIME, SECURITY_CACHE_FILE,
    ADDON_ID, ADDON_NAME, ADDON_VERSION
)
from utils import log

class SecurityManager:
    def __init__(self):
        pass
    
    def calculate_md5_hash(self, content):
        if not content:
            return None
        return hashlib.md5(content.encode('utf-8')).hexdigest()
    
    def verify_security_xml_hash(self, xml_content):
        if not SECURITY_XML_MD5_HASH or SECURITY_XML_MD5_HASH == "YOUR_SECURITY_XML_MD5_HASH_HERE":
            return False
        content_hash = self.calculate_md5_hash(xml_content)
        return content_hash == SECURITY_XML_MD5_HASH
    
    def verify_repository_installed(self):
        addons_path = xbmcvfs.translatePath("special://home/addons/")
        for repo_id in REQUIRED_REPO_IDS:
            repo_path = os.path.join(addons_path, repo_id)
            if xbmcvfs.exists(repo_path):
                return True
        
        try:
            db_path = xbmcvfs.translatePath("special://database/Addons33.db")
            if xbmcvfs.exists(db_path):
                conn = sqlite3.connect(db_path)
                cursor = conn.cursor()
                placeholders = ','.join('?' * len(REQUIRED_REPO_IDS))
                cursor.execute(f"SELECT addonID FROM installed WHERE addonID IN ({placeholders})", REQUIRED_REPO_IDS)
                result = cursor.fetchone()
                conn.close()
                if result:
                    return True
        except Exception as e:
            log(f"Database check error: {str(e)}", xbmc.LOGERROR)
        
        repos_xml_path = xbmcvfs.translatePath("special://home/addons/repositories.xml")
        if xbmcvfs.exists(repos_xml_path):
            try:
                with xbmcvfs.File(repos_xml_path, 'r') as f:
                    xml_content = f.read()
                if xml_content:
                    root = ET.fromstring(xml_content)
                    for repo in root.findall(".//info"):
                        addon_id = repo.get("id")
                        if addon_id and addon_id in REQUIRED_REPO_IDS:
                            return True
            except Exception as e:
                log(f"Repositories XML check error: {str(e)}", xbmc.LOGERROR)
        
        return False
    
    def show_repository_required_message(self):
        message = f"{ADDON_NAME} requires {REQUIRED_REPO_NAME} to function properly.\n\nPlease install the repository ZIP file to access content."
        xbmcgui.Dialog().ok("Repository Required", message)
    
    def is_playback_allowed(self):
        return self.verify_repository_installed()
    
    def fetch_security_xml(self):
        try:
            req = urllib.request.Request(SECURITY_XML_URL, 
                                       headers={'User-Agent': f'{ADDON_NAME}/{ADDON_VERSION} (Kodi)'})
            with urllib.request.urlopen(req, timeout=15) as response:
                if response.status == 200:
                    return response.read().decode()
            return None
        except Exception as e:
            log(f"Error fetching security XML: {str(e)}", xbmc.LOGERROR)
            return None
    
    def validate_security_xml(self, xml_content):
        try:
            if not xml_content:
                return False
            if not self.verify_security_xml_hash(xml_content):
                return False
            
            root = ET.fromstring(xml_content)
            for addon_elem in root.findall('.//addon'):
                addon_id = addon_elem.get('id')
                if addon_id == ADDON_ID:
                    status = addon_elem.get('status', 'enabled')
                    return status == 'enabled'
            return False
        except Exception as e:
            log(f"Error validating security XML: {str(e)}", xbmc.LOGERROR)
            return False
    
    def check_cached_security(self):
        try:
            if xbmcvfs.exists(SECURITY_CACHE_FILE):
                cache_time = os.path.getmtime(SECURITY_CACHE_FILE)
                current_time = time.time()
                if current_time - cache_time < SECURITY_CACHE_TIME:
                    with xbmcvfs.File(SECURITY_CACHE_FILE, 'r') as f:
                        xml_content = f.read()
                    if self.validate_security_xml(xml_content):
                        return True
        except Exception as e:
            log(f"Error checking cached security: {str(e)}", xbmc.LOGERROR)
        return False
    
    def cache_security_validation(self, xml_content):
        try:
            with xbmcvfs.File(SECURITY_CACHE_FILE, 'w') as f:
                f.write(xml_content)
        except Exception as e:
            log(f"Error caching security validation: {str(e)}", xbmc.LOGERROR)
    
    def execute_security_validation(self):
        if self.check_cached_security():
            return True
        
        xml_content = self.fetch_security_xml()
        if not xml_content:
            xbmcgui.Dialog().ok('Connection Error', 'Could not contact authorization server.')
            return False
        
        if not self.validate_security_xml(xml_content):
            xbmcgui.Dialog().ok('Authorization Error', 'This addon is not authorized to function.')
            return False
        
        self.cache_security_validation(xml_content)
        return True
    
    def is_security_valid(self):
        try:
            return self.execute_security_validation()
        except Exception as e:
            log(f"Security validation error: {str(e)}", xbmc.LOGERROR)
            xbmcgui.Dialog().ok('Security Error', 'An error occurred during security verification.')
            return False
