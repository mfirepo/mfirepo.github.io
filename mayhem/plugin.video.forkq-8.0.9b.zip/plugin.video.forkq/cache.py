import os
import time
import json
import xbmcvfs
import xbmcgui
import xbmc
import hashlib
from config import SUBLIST_CACHE_DIR, SUBLIST_CACHE_TIME, PLUGIN_KEY, ADDON_ICON, SECURITY_CACHE_FILE
from utils import log, ensure_directory
from encryption import encrypt, decrypt

class CacheManager:
    def __init__(self):
        ensure_directory(SUBLIST_CACHE_DIR)
    
    def get_sublist_cache_filename(self, url):
        url_hash = hashlib.md5(url.encode('utf-8')).hexdigest()
        return os.path.join(SUBLIST_CACHE_DIR, f"{url_hash}.cache")
    
    def get_cached_sublist(self, url):
        try:
            cache_file = self.get_sublist_cache_filename(url)
            
            if not xbmcvfs.exists(cache_file):
                return None
                
            cache_time = os.path.getmtime(cache_file)
            current_time = time.time()
            if current_time - cache_time > SUBLIST_CACHE_TIME:
                log("Cache expired, fetching fresh data")
                return None
                
            with xbmcvfs.File(cache_file, 'r') as f:
                encrypted_cache = f.read()
                
            if not encrypted_cache:
                return None
                
            decrypted_cache = decrypt(encrypted_cache, PLUGIN_KEY)
            if not decrypted_cache:
                return None
                
            data = json.loads(decrypted_cache)
            log(f"Loaded {len(data)} items from sublist cache for: {url}")
            return data
            
        except Exception as e:
            log(f"Error reading cached sublist: {str(e)}", xbmc.LOGERROR)
            return None
    
    def cache_sublist(self, url, data):
        try:
            cache_file = self.get_sublist_cache_filename(url)
            json_str = json.dumps(data)
            encrypted_cache = encrypt(json_str, PLUGIN_KEY)
            
            with xbmcvfs.File(cache_file, 'w') as f:
                f.write(encrypted_cache)
                
            log(f"Cached {len(data)} items for sublist: {url}")
            
        except Exception as e:
            log(f"Error caching sublist: {str(e)}", xbmc.LOGERROR)
    
    def clear_cache_safe(self):
        """Safe cache clearing without causing memory leaks"""
        try:
            files_deleted = 0
            cache_cleared = False
            
            # Clear sublist cache files one by one with delays
            if xbmcvfs.exists(SUBLIST_CACHE_DIR):
                dirs, files = xbmcvfs.listdir(SUBLIST_CACHE_DIR)
                for file in files:
                    if file.endswith('.cache'):
                        try:
                            cache_file = os.path.join(SUBLIST_CACHE_DIR, file)
                            if xbmcvfs.delete(cache_file):
                                log(f"Deleted cache file: {file}")
                                files_deleted += 1
                                cache_cleared = True
                            # Small delay between deletions to prevent memory pressure
                            xbmc.sleep(100)
                        except Exception as e:
                            log(f"Failed to delete {file}: {str(e)}")
                            continue
            
            # Clear security cache file
            if xbmcvfs.exists(SECURITY_CACHE_FILE):
                try:
                    if xbmcvfs.delete(SECURITY_CACHE_FILE):
                        log("Deleted security cache file")
                        files_deleted += 1
                        cache_cleared = True
                except Exception as e:
                    log(f"Failed to delete security cache: {str(e)}")
            
            # Show appropriate notification
            if cache_cleared:
                # Use simple notification without container refresh
                xbmcgui.Dialog().notification(
                    'Cache Cleared', 
                    f'Deleted {files_deleted} cache files',
                    ADDON_ICON, 
                    2000  # Shorter duration
                )
                log(f"Safe cache clearing completed - {files_deleted} files deleted")
            else:
                xbmcgui.Dialog().notification(
                    'Cache Info',
                    'No cache files found',
                    ADDON_ICON,
                    2000
                )
                log("No cache files found during clearing")
            
            return cache_cleared
            
        except Exception as e:
            log(f"Error during safe cache clearing: {str(e)}", xbmc.LOGERROR)
            # Use error notification without triggering refresh
            xbmcgui.Dialog().notification(
                'Cache Error',
                'Failed to clear some cache files',
                xbmcgui.NOTIFICATION_WARNING,  # Use warning instead of error
                2000
            )
            return False
    
    def clear_old_cache_auto(self):
        """Automatically clear expired cache files without user interaction"""
        try:
            files_cleared = 0
            current_time = time.time()
            
            if xbmcvfs.exists(SUBLIST_CACHE_DIR):
                dirs, files = xbmcvfs.listdir(SUBLIST_CACHE_DIR)
                for file in files:
                    if file.endswith('.cache'):
                        cache_file = os.path.join(SUBLIST_CACHE_DIR, file)
                        try:
                            cache_time = os.path.getmtime(cache_file)
                            if current_time - cache_time > SUBLIST_CACHE_TIME:
                                if xbmcvfs.delete(cache_file):
                                    files_cleared += 1
                                    log(f"Auto-deleted expired cache: {file}")
                        except:
                            continue
            
            if files_cleared > 0:
                log(f"Auto-cleanup removed {files_cleared} expired cache files")
            
            return files_cleared
            
        except Exception as e:
            log(f"Error during auto cache cleanup: {str(e)}")
            return 0

# Update your router to use the safe method
def handle_cache_clear():
    cache_manager = CacheManager()
    # Use safe clearing method
    cache_manager.clear_cache_safe()
    # DO NOT call Container.Refresh after cache clearing
    # Let the user manually refresh if needed
