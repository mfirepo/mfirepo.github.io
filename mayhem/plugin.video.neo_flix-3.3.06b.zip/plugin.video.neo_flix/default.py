import sys
import json
import base64
import urllib.request
import urllib.parse
import urllib.error
import xbmcplugin
import xbmcgui
import xbmcaddon
import xbmcvfs
import resolveurl
import time
import hashlib
import os
import sqlite3
import re

try:
    import inputstreamhelper
    HAS_INPUTSTREAM_HELPER = True
except ImportError:
    HAS_INPUTSTREAM_HELPER = False

ADDON = xbmcaddon.Addon()
ADDON_ID = ADDON.getAddonInfo('id')
ADDON_NAME = ADDON.getAddonInfo('name')
ADDON_VERSION = ADDON.getAddonInfo('version')
ADDON_PATH = ADDON.getAddonInfo('path')
PLUGIN_KEY = "plugin.video.neo_flix"
HANDLE = int(sys.argv[1])

SECURITY_XML_MD5_HASH = "a4ce63b1f4906d367ff2e0d45e3c363e"
REQUIRED_REPO_IDS = ["repository.cMaNWizard", "repository.madforit"]
REQUIRED_REPO_NAME = "cMans Repo"
SECURITY_XML_URL = "https://bitbucket.org/halcyonhal/db/raw/main/neosecurity.xml"
SECURITY_CACHE_TIME = 86400
SECURITY_CACHE_FILE = xbmcvfs.translatePath(f"special://temp/{ADDON_ID}_security_cache.xml")
LOCAL_JSON_PATH = xbmcvfs.translatePath(f"special://home/addons/{ADDON_ID}/resources/data.json")
OBFUSCATED_JSON_KEY = PLUGIN_KEY + "json_encryption_key"

# Sublist cache settings - Updated to 24 hours with XOR encryption
SUBLIST_CACHE_TIME = 86400  # 24 hours
SUBLIST_CACHE_DIR = xbmcvfs.translatePath(f"special://temp/{ADDON_ID}_cache/")

ADDON_ICON = xbmcvfs.translatePath(f"special://home/addons/{ADDON_ID}/icon.png")
ADDON_FANART = xbmcvfs.translatePath(f"special://home/addons/{ADDON_ID}/fanart.jpg")

def log(message, level=xbmc.LOGINFO):
    xbmc.log(f"[{ADDON_NAME} v{ADDON_VERSION}] {message}", level)

def encrypt(text, key):
    try:
        encrypted_bytes = bytes([ord(c) ^ ord(key[i % len(key)]) for i, c in enumerate(text)])
        return base64.urlsafe_b64encode(encrypted_bytes).decode()
    except Exception:
        return ""

def decrypt(encrypted_text, key):
    try:
        encrypted_bytes = base64.urlsafe_b64decode(encrypted_text.encode())
        decrypted_chars = [chr(b ^ ord(key[i % len(key)])) for i, b in enumerate(encrypted_bytes)]
        return ''.join(decrypted_chars)
    except Exception:
        return ""

def calculate_md5_hash(content):
    if not content:
        return None
    return hashlib.md5(content.encode('utf-8')).hexdigest()

def verify_security_xml_hash(xml_content):
    if not SECURITY_XML_MD5_HASH or SECURITY_XML_MD5_HASH == "YOUR_SECURITY_XML_MD5_HASH_HERE":
        return False
    content_hash = calculate_md5_hash(xml_content)
    return content_hash == SECURITY_XML_MD5_HASH

def verify_repository_installed():
    addons_path = xbmcvfs.translatePath("special://home/addons/")
    for repo_id in REQUIRED_REPO_IDS:
        repo_path = os.path.join(addons_path, repo_id)
        if xbmcvfs.exists(repo_path):
            return True
    try:
        db_path = xbmcvfs.translatePath("special://database/Addons33.db")
        if xbmcvfs.exists(db_path):
            conn = sqlite3.connect(db_path)
            cursor = conn.cursor()
            placeholders = ','.join('?' * len(REQUIRED_REPO_IDS))
            cursor.execute(f"SELECT addonID FROM installed WHERE addonID IN ({placeholders})", REQUIRED_REPO_IDS)
            result = cursor.fetchone()
            conn.close()
            if result:
                return True
    except Exception:
        pass
    repos_xml_path = xbmcvfs.translatePath("special://home/addons/repositories.xml")
    if xbmcvfs.exists(repos_xml_path):
        try:
            import xml.etree.ElementTree as ET
            with xbmcvfs.File(repos_xml_path, 'r') as f:
                xml_content = f.read()
            if xml_content:
                root = ET.fromstring(xml_content)
                for repo in root.findall(".//info"):
                    addon_id = repo.get("id")
                    if addon_id and addon_id in REQUIRED_REPO_IDS:
                        return True
        except Exception:
            pass
    return False

def show_repository_required_message():
    message = f"{ADDON_NAME} requires {REQUIRED_REPO_NAME} to function properly.\n\nPlease install the repository ZIP file to access content."
    xbmcgui.Dialog().ok("Repository Required", message)

def is_playback_allowed():
    return verify_repository_installed()

def get_url(**kwargs):
    return f"{sys.argv[0]}?{urllib.parse.urlencode(kwargs)}"

def call_external_addon(addon_id, path, parameters=None):
    try:
        base_url = f"plugin://{addon_id}/{path}"
        if parameters:
            param_string = "&".join([f"{k}={v}" for k, v in parameters.items()])
            full_url = f"{base_url}?{param_string}"
        else:
            full_url = base_url
        xbmc.executebuiltin(f'Container.Update({full_url})')
        return True
    except Exception:
        return False

def launch_sportjet_stream(code='us'):
    try:
        return call_external_addon('plugin.video.forkq', 'sportjetextractors/games/TVGarden', {'code': code})
    except Exception:
        return False

def clear_cache_manual():
    """Manual cache clearing function without confirmation dialog"""
    try:
        cache_cleared = False
        files_deleted = 0
        
        # Clear sublist cache directory
        if xbmcvfs.exists(SUBLIST_CACHE_DIR):
            dirs, files = xbmcvfs.listdir(SUBLIST_CACHE_DIR)
            for file in files:
                if file.endswith('.cache'):
                    cache_file = os.path.join(SUBLIST_CACHE_DIR, file)
                    xbmcvfs.delete(cache_file)
                    log(f"Deleted cache file: {file}")
                    files_deleted += 1
                    cache_cleared = True
        
        # Clear security cache file
        if xbmcvfs.exists(SECURITY_CACHE_FILE):
            xbmcvfs.delete(SECURITY_CACHE_FILE)
            log("Deleted security cache file")
            files_deleted += 1
            cache_cleared = True
            
        if cache_cleared:
            xbmcgui.Dialog().notification('Cache Cleared', 
                                         f'Cache Files Deleted',
                                         ADDON_ICON, 3000)
            log(f"Manual cache clearing completed - {files_deleted} files deleted")
            return True
        else:
            xbmcgui.Dialog().notification('Cache Info', 
                                         'No cache files found to clear',
                                         ADDON_ICON, 3000)
            log("No cache files found during manual clearing")
            return False
            
    except Exception as e:
        log(f"Error during manual cache clearing: {str(e)}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Cache Error', 
                                     'Failed to clear cache files',
                                     xbmcgui.NOTIFICATION_ERROR, 3000)
        return False

def load_local_json():
    """Load JSON data from local file with XOR encryption"""
    try:
        if not xbmcvfs.exists(LOCAL_JSON_PATH):
            log(f"Local JSON file not found: {LOCAL_JSON_PATH}", xbmc.LOGERROR)
            return []
            
        with xbmcvfs.File(LOCAL_JSON_PATH, 'r') as f:
            encrypted_content = f.read()
            
        if not encrypted_content:
            log("Local JSON file is empty", xbmc.LOGERROR)
            return []
            
        # Always try decryption first for XOR encrypted content
        decrypted_content = decrypt(encrypted_content, OBFUSCATED_JSON_KEY)
        if decrypted_content:
            try:
                data = json.loads(decrypted_content)
                log(f"Successfully loaded {len(data)} menu items from local JSON (XOR decrypted)")
                return data
            except json.JSONDecodeError:
                log("Failed to parse decrypted JSON content", xbmc.LOGERROR)
                return []
        else:
            # If decryption fails, try parsing as plain JSON
            try:
                data = json.loads(encrypted_content)
                log(f"Successfully loaded {len(data)} menu items from local JSON (plain)")
                return data
            except json.JSONDecodeError:
                log("Failed to parse JSON content as either encrypted or plain", xbmc.LOGERROR)
                return []
                
    except Exception as e:
        log(f"Error loading local JSON: {str(e)}", xbmc.LOGERROR)
        
    return []

def get_main_menu_data():
    """Get main menu data and add Clear Cache option"""
    menu_data = load_local_json()
    
    # Add Clear Cache option to the end of the menu
    clear_cache_item = {
        'title': '[COLOR lime]Clear Cache[/COLOR]',
        'summary': 'Clear all temporary cache files to free up space and resolve potential issues',
        'thumbnail': ADDON_ICON,
        'fanart': ADDON_FANART,
        'type': 'clear_cache'
    }
    
    if menu_data:
        menu_data.append(clear_cache_item)
    else:
        menu_data = [clear_cache_item]
        
    return menu_data

def get_sublist_cache_filename(url):
    """Generate cache filename from URL using hash"""
    url_hash = hashlib.md5(url.encode('utf-8')).hexdigest()
    return os.path.join(SUBLIST_CACHE_DIR, f"{url_hash}.cache")

def ensure_cache_directory():
    """Create cache directory if it doesn't exist"""
    if not xbmcvfs.exists(SUBLIST_CACHE_DIR):
        xbmcvfs.mkdirs(SUBLIST_CACHE_DIR)

def get_cached_sublist(url):
    """Get cached sublist data with XOR encryption"""
    try:
        ensure_cache_directory()
        cache_file = get_sublist_cache_filename(url)
        
        if not xbmcvfs.exists(cache_file):
            return None
            
        # Check cache age
        cache_time = os.path.getmtime(cache_file)
        current_time = time.time()
        if current_time - cache_time > SUBLIST_CACHE_TIME:
            log("Cache expired, fetching fresh data")
            return None
            
        # Read and decrypt cached data
        with xbmcvfs.File(cache_file, 'r') as f:
            encrypted_cache = f.read()
            
        if not encrypted_cache:
            return None
            
        # Decrypt using XOR with PLUGIN_KEY
        decrypted_cache = decrypt(encrypted_cache, PLUGIN_KEY)
        if not decrypted_cache:
            return None
            
        data = json.loads(decrypted_cache)
        log(f"Loaded {len(data)} items from sublist cache for: {url}")
        return data
        
    except Exception as e:
        log(f"Error reading cached sublist: {str(e)}", xbmc.LOGERROR)
        return None

def cache_sublist(url, data):
    """Cache sublist data with XOR encryption"""
    try:
        ensure_cache_directory()
        cache_file = get_sublist_cache_filename(url)
        
        # Encrypt data before caching
        json_str = json.dumps(data)
        encrypted_cache = encrypt(json_str, PLUGIN_KEY)
        
        with xbmcvfs.File(cache_file, 'w') as f:
            f.write(encrypted_cache)
            
        log(f"Cached {len(data)} items for sublist: {url}")
        
    except Exception as e:
        log(f"Error caching sublist: {str(e)}", xbmc.LOGERROR)

def fetch_json(url):
    """Fetch JSON from remote URL for submenus with caching"""
    # Try to get from cache first
    cached_data = get_cached_sublist(url)
    if cached_data is not None:
        return cached_data
        
    try:
        log(f"Fetching JSON from: {url}")
        req = urllib.request.Request(url, headers={
            'User-Agent': f'{ADDON_NAME}/{ADDON_VERSION} (Kodi)',
            'Accept': 'application/json'
        })
        with urllib.request.urlopen(req, timeout=30) as response:
            data = json.loads(response.read().decode())
        
        log(f"Successfully fetched {len(data) if isinstance(data, list) else 'unknown'} items")
        
        # Cache the fetched data with XOR encryption
        cache_sublist(url, data)
        
        return data
        
    except Exception as e:
        log(f"Error fetching JSON from {url}: {str(e)}", xbmc.LOGERROR)
        return []

def fetch_security_xml():
    try:
        req = urllib.request.Request(SECURITY_XML_URL, headers={'User-Agent': f'{ADDON_NAME}/{ADDON_VERSION} (Kodi)'})
        with urllib.request.urlopen(req, timeout=15) as response:
            if response.status == 200:
                return response.read().decode()
        return None
    except Exception:
        return None

def validate_security_xml(xml_content):
    try:
        if not xml_content:
            return False
        if not verify_security_xml_hash(xml_content):
            return False
        import xml.etree.ElementTree as ET
        root = ET.fromstring(xml_content)
        for addon_elem in root.findall('.//addon'):
            addon_id = addon_elem.get('id')
            if addon_id == ADDON_ID:
                status = addon_elem.get('status', 'enabled')
                return status == 'enabled'
        return False
    except Exception:
        return False

def check_cached_security():
    try:
        if xbmcvfs.exists(SECURITY_CACHE_FILE):
            cache_time = os.path.getmtime(SECURITY_CACHE_FILE)
            current_time = time.time()
            if current_time - cache_time < SECURITY_CACHE_TIME:
                with xbmcvfs.File(SECURITY_CACHE_FILE, 'r') as f:
                    xml_content = f.read()
                if validate_security_xml(xml_content):
                    return True
    except:
        pass
    return False

def cache_security_validation(xml_content):
    try:
        with xbmcvfs.File(SECURITY_CACHE_FILE, 'w') as f:
            f.write(xml_content)
    except Exception:
        pass

def execute_security_validation():
    if check_cached_security():
        return True
    xml_content = fetch_security_xml()
    if not xml_content:
        xbmcgui.Dialog().ok('Connection Error', 'Could not contact authorization server.')
        return False
    if not validate_security_xml(xml_content):
        xbmcgui.Dialog().ok('Authorization Error', 'This addon is not authorized to function.')
        return False
    cache_security_validation(xml_content)
    return True

def is_security_valid():
    try:
        return execute_security_validation()
    except Exception:
        xbmcgui.Dialog().ok('Security Error', 'An error occurred during security verification.')
        return False

def setup_robust_inputstream(list_item, url):
    list_item.setProperty('inputstream', 'inputstream.adaptive')
    list_item.setProperty('inputstream.adaptive.manifest_type', 'hls')
    list_item.setProperty('inputstream.adaptive.manifest_update_parameter', 'full')
    list_item.setProperty('inputstream.adaptive.license_flags', 'persistent_storage')
    list_item.setProperty('inputstream.adaptive.license_type', 'com.widevine.alpha')
    list_item.setProperty('inputstream.adaptive.connection_timeout', '60')
    list_item.setProperty('inputstream.adaptive.manifest_timeout', '60')
    list_item.setProperty('inputstream.adaptive.live_delay', '3')
    list_item.setProperty('inputstream.adaptive.max_bandwidth', '12000000')
    list_item.setProperty('inputstream.adaptive.min_bandwidth', '500000')
    list_item.setProperty('inputstream.adaptive.max_resolution', '1080p')
    list_item.setProperty('inputstream.adaptive.network_caching', '20000')
    list_item.setProperty('inputstream.adaptive.segment_download_retries', '10')
    list_item.setProperty('inputstream.adaptive.segment_download_timeout', '45')
    list_item.setProperty('inputstream.adaptive.segment_download_retry_wait', '5')
    list_item.setProperty('inputstream.adaptive.max_segment_count', '50')
    list_item.setProperty('inputstream.adaptive.play_timeshift_buffer', 'true')
    list_item.setProperty('inputstream.adaptive.ignore_manifest_segment_timestamps', 'true')
    return True

def get_rotated_user_agent():
    agents = [
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/119.0.0.0 Safari/537.36',
        'Mozilla/5.0 (Windows NT 10.0; Win64; x64; rv:121.0) Gecko/20100101 Firefox/121.0',
        'Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36',
        'Mozilla/5.0 (X11; Linux x86_64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36'
    ]
    return agents[int(time.time()) % len(agents)]

def extract_m3u8_segments(m3u8_content):
    segments = []
    lines = m3u8_content.split('\n')
    for line in lines:
        if line.startswith('http') and '.ts' in line:
            segments.append(line.strip())
    return segments

def get_refreshed_stream(base_url, max_retries=5):
    for attempt in range(max_retries):
        try:
            timestamp = int(time.time())
            user_agent = get_rotated_user_agent()
            
            refreshed_url = f"{base_url}{'&' if '?' in base_url else '?'}_t={timestamp}&_={timestamp}"
            
            req = urllib.request.Request(refreshed_url, headers={
                'User-Agent': user_agent,
                'Accept': '*/*',
                'Accept-Language': 'en-US,en;q=0.9',
                'Accept-Encoding': 'identity',
                'Connection': 'keep-alive',
                'Referer': 'http://cord-cutter.net/',
                'Origin': 'http://cord-cutter.net',
                'Cache-Control': 'no-cache',
                'Pragma': 'no-cache'
            })
            
            with urllib.request.urlopen(req, timeout=15) as response:
                if response.status == 200:
                    content = response.read().decode('utf-8')
                    if '#EXTM3U' in content:
                        log(f"Stream refresh successful - attempt {attempt + 1}")
                        return refreshed_url
                    else:
                        log(f"Invalid M3U8 content received")
                        
        except Exception as e:
            log(f"Stream refresh attempt {attempt + 1} failed: {str(e)}")
            time.sleep(3)
    
    log("All stream refresh attempts failed")
    return base_url

def check_stream_health(url):
    try:
        req = urllib.request.Request(url, headers={
            'User-Agent': get_rotated_user_agent(),
            'Accept': '*/*',
            'Cache-Control': 'no-cache'
        })
        with urllib.request.urlopen(req, timeout=15) as response:
            content = response.read().decode('utf-8')
            if '#EXTM3U' in content and '#EXTINF' in content:
                segments = extract_m3u8_segments(content)
                log(f"Stream health check passed - {len(segments)} segments found")
                return True
        return False
    except Exception as e:
        log(f"Stream health check failed: {str(e)}")
        return False

def create_robust_headers():
    user_agent = get_rotated_user_agent()
    return {
        'User-Agent': user_agent,
        'Accept': '*/*',
        'Accept-Language': 'en-US,en;q=0.9',
        'Accept-Encoding': 'identity',
        'Connection': 'keep-alive',
        'Referer': 'http://cord-cutter.net/',
        'Origin': 'http://cord-cutter.net',
        'Sec-Fetch-Dest': 'empty',
        'Sec-Fetch-Mode': 'cors',
        'Sec-Fetch-Site': 'same-origin',
        'Cache-Control': 'no-cache',
        'Pragma': 'no-cache'
    }

def play_robust_m3u8(url, list_item):
    list_item.setMimeType('application/vnd.apple.mpegurl')
    list_item.setContentLookup(False)
    list_item.setProperty('IsPlayable', 'true')
    
    setup_robust_inputstream(list_item, url)
    
    headers = create_robust_headers()
    header_string = '&'.join([f'{k}={urllib.parse.quote(v)}' for k, v in headers.items()])
    list_item.setProperty('inputstream.adaptive.stream_headers', header_string)
    list_item.setProperty('http-headers', header_string)
    
    list_item.setPath(url)
    xbmcplugin.setResolvedUrl(HANDLE, True, list_item)
    return True

def monitor_playback():
    player = xbmc.Player()
    monitor = xbmc.Monitor()
    last_check = time.time()
    
    while not monitor.abortRequested() and player.isPlaying():
        current_time = time.time()
        if current_time - last_check > 30:
            try:
                playing_file = player.getPlayingFile()
                if playing_file and '.m3u8' in playing_file:
                    if not check_stream_health(playing_file):
                        log("Stream health check failed during playback")
                        return False
                last_check = current_time
            except:
                pass
        if monitor.waitForAbort(5):
            break
    return True

def play_video_with_recovery(link):
    if not is_security_valid():
        return
        
    original_url = decrypt(link, ADDON_ID)
    if not original_url:
        return
        
    max_attempts = 3
    for attempt in range(max_attempts):
        try:
            list_item = xbmcgui.ListItem()
            current_url = original_url
            
            if attempt > 0:
                current_url = get_refreshed_stream(original_url)
                log(f"Playback attempt {attempt + 1} with refreshed URL")
            
            if current_url.endswith('.m3u8'):
                if play_robust_m3u8(current_url, list_item):
                    if monitor_playback():
                        log("Playback completed successfully")
                        return True
                    else:
                        log("Playback monitoring detected stream failure")
                        continue
            else:
                resolved_url = resolveurl.resolve(current_url)
                if resolved_url:
                    list_item.setPath(resolved_url)
                else:
                    list_item.setPath(current_url)
                    
                list_item.setContentLookup(False)
                xbmcplugin.setResolvedUrl(HANDLE, True, list_item)
                return True
                
        except Exception as e:
            log(f"Playback attempt {attempt + 1} failed: {str(e)}")
            if attempt < max_attempts - 1:
                time.sleep(5)
    
    xbmcgui.Dialog().notification('Playback Error', 'Could not establish stable stream connection', xbmcgui.NOTIFICATION_ERROR)
    xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())

def play_video(link):
    if not is_security_valid():
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
    if not is_playback_allowed():
        show_repository_required_message()
        xbmcplugin.setResolvedUrl(HANDLE, False, xbmcgui.ListItem())
        return
        
    play_video_with_recovery(link)

def get_stream_quality_score(stream):
    """Calculate quality score for stream based on resolution and audio quality"""
    score = 0
    label = stream.get('label', '').lower()
    quality = stream.get('quality', '').lower()
    size = stream.get('size', '').lower()
    
    # Resolution scoring
    if '4k' in label or '4k' in quality or '2160' in label:
        score += 100
    elif '1080' in label or '1080' in quality or 'fhd' in label:
        score += 80
    elif '720' in label or '720' in quality or 'hd' in label:
        score += 60
    elif '480' in label or '480' in quality or 'sd' in label:
        score += 40
    
    # Audio quality scoring
    if 'dolby' in label or 'dolby' in quality or 'atmos' in label:
        score += 30
    elif 'dts' in label or 'dts' in quality:
        score += 25
    elif '5.1' in label or '5.1' in quality:
        score += 20
    elif 'ac3' in label or 'ac3' in quality:
        score += 15
    
    # Source reliability scoring
    if 'official' in label or 'original' in label:
        score += 25
    elif 'web' in label or 'web-dl' in label:
        score += 20
    elif 'bluray' in label or 'bdrip' in label:
        score += 15
    
    # Size-based scoring (larger files often mean better quality)
    if 'gb' in size or 'gib' in size:
        try:
            size_num = float(re.findall(r'(\d+\.?\d*)\s*(gb|gib)', size)[0][0])
            score += min(size_num * 5, 50)  # Cap at 50 points for size
        except:
            pass
    
    # Penalize cam/ts/screener quality
    if 'cam' in label or 'ts' in label or 'screener' in label or 'tc' in label:
        score -= 50
    
    return max(score, 0)  # Ensure score doesn't go negative

def get_best_stream(streams):
    """Select the best stream based on quality score"""
    if not streams:
        return None
    
    scored_streams = []
    for stream in streams:
        score = get_stream_quality_score(stream)
        scored_streams.append((score, stream))
    
    # Sort by score descending
    scored_streams.sort(key=lambda x: x[0], reverse=True)
    
    best_score, best_stream = scored_streams[0]
    log(f"Selected best stream: {best_stream.get('label', 'Unknown')} with score: {best_score}")
    
    # Log all stream scores for debugging
    for score, stream in scored_streams:
        log(f"Stream: {stream.get('label', 'Unknown')} - Score: {score}")
    
    return best_stream

def show_stream_selection_dialog(streams):
    """Show dialog box for user to select a stream"""
    if not streams:
        return None
    
    # Create list of stream labels for the dialog
    stream_labels = []
    for stream in streams:
        label = stream.get('label', 'Unknown Stream')
        quality = stream.get('quality', '')
        size = stream.get('size', '')
        
        # Build display string with available information
        display_text = label
        if quality:
            display_text += f" - {quality}"
        if size:
            display_text += f" ({size})"
            
        stream_labels.append(display_text)
    
    # Show selection dialog
    dialog = xbmcgui.Dialog()
    selected_index = dialog.select('Choose Stream Quality', stream_labels)
    
    if selected_index >= 0:
        log(f"User selected stream: {stream_labels[selected_index]}")
        return streams[selected_index]
    else:
        log("User cancelled stream selection")
        return None

def choose_and_play_stream(encrypted_json):
    """Show stream selection dialog to user when multiple streams are available"""
    if not is_security_valid():
        return
    if not is_playback_allowed():
        show_repository_required_message()
        return
    try:
        decrypted = decrypt(encrypted_json, PLUGIN_KEY)
        streams = json.loads(decrypted)
        if not streams:
            xbmcgui.Dialog().notification('No Streams', 'No streams available', xbmcgui.NOTIFICATION_ERROR)
            return
        
        # If only one stream, play it automatically
        if len(streams) == 1:
            log("Only one stream available, playing it automatically")
            play_video(encrypt(streams[0]['url'], ADDON_ID))
        else:
            # Show selection dialog for multiple streams
            log(f"Showing stream selection dialog with {len(streams)} options")
            selected_stream = show_stream_selection_dialog(streams)
            if selected_stream:
                play_video(encrypt(selected_stream['url'], ADDON_ID))
            else:
                log("No stream selected by user")
            
    except Exception as e:
        log(f"Stream selection error: {str(e)}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification('Selection Error', 'Failed to choose a stream.', xbmcgui.NOTIFICATION_ERROR)

def list_items(json_url=None, is_main_list=False):
    if not is_security_valid():
        xbmcplugin.endOfDirectory(HANDLE)
        return
    if not verify_repository_installed():
        show_repository_required_message()
        xbmcplugin.endOfDirectory(HANDLE)
        return
        
    if is_main_list:
        log("Loading main menu data from local JSON...")
        items = get_main_menu_data()
    else:
        decrypted_url = decrypt(json_url, PLUGIN_KEY)
        log(f"Loading submenu from: {decrypted_url}")
        items = fetch_json(decrypted_url)
        
    if not items:
        log("No items found to display")
        xbmcgui.Dialog().notification('No Content', 'No content available at this time.', xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.endOfDirectory(HANDLE)
        return
        
    log(f"Displaying {len(items)} items")
    
    for item in items:
        title = item.get('title', 'Untitled')
        summary = item.get('summary', 'No description available.')
        thumbnail = item.get('thumbnail', ADDON_ICON)
        fanart = item.get('fanart', ADDON_FANART)
        list_item = xbmcgui.ListItem(label=title)
        list_item.setArt({
            'thumb': thumbnail,
            'icon': thumbnail,
            'fanart': fanart
        })
        info_labels = {'title': title, 'plot': summary, 'genre': item.get('genre', ''), 'year': item.get('year', ''), 'rating': item.get('rating', '')}
        list_item.setInfo('video', info_labels)
        
        if item.get('type') == 'clear_cache':
            # Clear Cache action
            url = get_url(action='clear_cache')
            list_item.setProperty('IsPlayable', 'false')
            xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=False)
        elif item.get('type') == 'external_addon':
            addon_id = item.get('addon_id')
            addon_path = item.get('addon_path')
            addon_params = item.get('addon_params', {})
            base_url = f"plugin://{addon_id}/{addon_path}"
            if addon_params:
                param_string = "&".join([f"{k}={v}" for k, v in addon_params.items()])
                external_url = f"{base_url}?{param_string}"
            else:
                external_url = base_url
            xbmcplugin.addDirectoryItem(HANDLE, external_url, list_item, isFolder=True)
        elif item.get('is_dir', False):
            url = get_url(action='list', url=encrypt(item['link'], PLUGIN_KEY))
            xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=True)
        elif item.get('link') == 'magnet:':
            url = get_url(action='no_link')
            xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=False)
        elif 'links' in item and isinstance(item['links'], list):
            encoded_links = encrypt(json.dumps(item['links']), PLUGIN_KEY)
            url = get_url(action='choose_stream', urls=encoded_links)
            list_item.setProperty('IsPlayable', 'true')
            xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=False)
        elif 'link' in item:
            url = get_url(action='play', url=encrypt(item['link'], ADDON_ID))
            list_item.setProperty('IsPlayable', 'true')
            xbmcplugin.addDirectoryItem(HANDLE, url, list_item, isFolder=False)
        else:
            log(f"Item '{title}' has no valid action type")
            
    xbmcplugin.endOfDirectory(HANDLE)

def launch_external_addon_handler(addon_id_encrypted, addon_path_encrypted, addon_params_encrypted):
    if not is_security_valid():
        return
    try:
        addon_id = decrypt(addon_id_encrypted, PLUGIN_KEY)
        addon_path = decrypt(addon_path_encrypted, PLUGIN_KEY)
        addon_params_str = decrypt(addon_params_encrypted, PLUGIN_KEY)
        addon_params = json.loads(addon_params_str) if addon_params_str else {}
        success = call_external_addon(addon_id, addon_path, addon_params)
        if not success:
            xbmcgui.Dialog().notification('External Addon Error', f'Could not launch {addon_id}', xbmcgui.NOTIFICATION_ERROR)
    except Exception:
        xbmcgui.Dialog().notification('Launch Error', 'Failed to launch external addon', xbmcgui.NOTIFICATION_ERROR)

def router(params):
    log(f"Router called with params: {params}")
    
    if not is_security_valid():
        xbmcplugin.endOfDirectory(HANDLE)
        return
        
    action = params.get('action', '')
    url = params.get('url', '')
    urls = params.get('urls', '')
    addon_id = params.get('addon_id', '')
    addon_path = params.get('addon_path', '')
    addon_params = params.get('addon_params', '')
    
    if action == 'list' and url:
        list_items(url, is_main_list=False)
    elif action == 'play' and url:
        play_video(url)
    elif action == 'choose_stream' and urls:
        choose_and_play_stream(urls)
    elif action == 'launch_external' and addon_id and addon_path:
        launch_external_addon_handler(addon_id, addon_path, addon_params)
    elif action == 'clear_cache':
        clear_cache_manual()
        # Refresh the directory after clearing cache
        xbmc.executebuiltin('Container.Refresh')
    elif action == 'main_menu':
        list_items(is_main_list=True)
    elif action == 'no_link':
        xbmcgui.Dialog().notification('No Stream', 'This item is not playable.', xbmcgui.NOTIFICATION_INFO)
    else:
        if not verify_repository_installed():
            show_repository_required_message()
            xbmcplugin.endOfDirectory(HANDLE)
            return
        list_items(is_main_list=True)

if __name__ == '__main__':
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    router(params)
