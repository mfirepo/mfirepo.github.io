import sys
import urllib.parse
import xbmcplugin
from router import Router

def main():
    params = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    router = Router()
    router.route(params)

if __name__ == '__main__':
    main()
