import os
import time
import json
import xbmcvfs
import xbmcgui
import xbmc
import hashlib
from config import SUBLIST_CACHE_DIR, SUBLIST_CACHE_TIME, PLUGIN_KEY, ADDON_ICON, SECURITY_CACHE_FILE  # ADD SECURITY_CACHE_FILE
from utils import log, ensure_directory
from encryption import encrypt, decrypt

class CacheManager:
    def __init__(self):
        ensure_directory(SUBLIST_CACHE_DIR)
    
    def get_sublist_cache_filename(self, url):
        url_hash = hashlib.md5(url.encode('utf-8')).hexdigest()
        return os.path.join(SUBLIST_CACHE_DIR, f"{url_hash}.cache")
    
    def get_cached_sublist(self, url):
        try:
            cache_file = self.get_sublist_cache_filename(url)
            
            if not xbmcvfs.exists(cache_file):
                return None
                
            cache_time = os.path.getmtime(cache_file)
            current_time = time.time()
            if current_time - cache_time > SUBLIST_CACHE_TIME:
                log("Cache expired, fetching fresh data")
                return None
                
            with xbmcvfs.File(cache_file, 'r') as f:
                encrypted_cache = f.read()
                
            if not encrypted_cache:
                return None
                
            decrypted_cache = decrypt(encrypted_cache, PLUGIN_KEY)
            if not decrypted_cache:
                return None
                
            data = json.loads(decrypted_cache)
            log(f"Loaded {len(data)} items from sublist cache for: {url}")
            return data
            
        except Exception as e:
            log(f"Error reading cached sublist: {str(e)}", xbmc.LOGERROR)
            return None
    
    def cache_sublist(self, url, data):
        try:
            cache_file = self.get_sublist_cache_filename(url)
            json_str = json.dumps(data)
            encrypted_cache = encrypt(json_str, PLUGIN_KEY)
            
            with xbmcvfs.File(cache_file, 'w') as f:
                f.write(encrypted_cache)
                
            log(f"Cached {len(data)} items for sublist: {url}")
            
        except Exception as e:
            log(f"Error caching sublist: {str(e)}", xbmc.LOGERROR)
    
    def clear_cache_manual(self):
        """Manual cache clearing function"""
        try:
            cache_cleared = False
            files_deleted = 0
            
            # Clear sublist cache directory
            if xbmcvfs.exists(SUBLIST_CACHE_DIR):
                dirs, files = xbmcvfs.listdir(SUBLIST_CACHE_DIR)
                for file in files:
                    if file.endswith('.cache'):
                        cache_file = os.path.join(SUBLIST_CACHE_DIR, file)
                        xbmcvfs.delete(cache_file)
                        log(f"Deleted cache file: {file}")
                        files_deleted += 1
                        cache_cleared = True
            
            # Clear security cache file
            if xbmcvfs.exists(SECURITY_CACHE_FILE):
                xbmcvfs.delete(SECURITY_CACHE_FILE)
                log("Deleted security cache file")
                files_deleted += 1
                cache_cleared = True
                
            if cache_cleared:
                xbmcgui.Dialog().notification('Cache Cleared', 
                                             f'Cache Files Deleted',
                                             ADDON_ICON, 3000)
                log(f"Manual cache clearing completed - {files_deleted} files deleted")
                return True
            else:
                xbmcgui.Dialog().notification('Cache Info', 
                                             'No cache files found to clear',
                                             ADDON_ICON, 3000)
                log("No cache files found during manual clearing")
                return False
                
        except Exception as e:
            log(f"Error during manual cache clearing: {str(e)}", xbmc.LOGERROR)
            xbmcgui.Dialog().notification('Cache Error', 
                                         'Failed to clear cache files',
                                         xbmcgui.NOTIFICATION_ERROR, 3000)
            return False
