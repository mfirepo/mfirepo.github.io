import xbmcplugin
import xbmcgui
import sys
from config import HANDLE
from utils import log
from security import SecurityManager
from menu import MenuManager
from playback import PlaybackManager
from cache import CacheManager

class Router:
    def __init__(self):
        self.security_manager = SecurityManager()
        self.menu_manager = MenuManager()
        self.playback_manager = PlaybackManager()
        self.cache_manager = CacheManager()
        self.handle = HANDLE
    
    def route(self, params):
        log(f"Router called with params: {params}")
        
        if not self.security_manager.is_security_valid():
            xbmcplugin.endOfDirectory(self.handle)
            return
            
        action = params.get('action', '')
        url = params.get('url', '')
        urls = params.get('urls', '')
        addon_id = params.get('addon_id', '')
        addon_path = params.get('addon_path', '')
        addon_params = params.get('addon_params', '')
        
        if action == 'list' and url:
            self.menu_manager.list_items(url, is_main_list=False)
        elif action == 'play' and url:
            self.playback_manager.play_video(url)
        elif action == 'choose_stream' and urls:
            self.playback_manager.choose_and_play_stream(urls)
        elif action == 'launch_external' and addon_id and addon_path:
            self.menu_manager.launch_external_addon_handler(addon_id, addon_path, addon_params)
        elif action == 'clear_cache':
            self.cache_manager.clear_cache_manual()
            xbmc.executebuiltin('Container.Refresh')
        elif action == 'main_menu':
            self.menu_manager.list_items(is_main_list=True)
        elif action == 'no_link':
            xbmcgui.Dialog().notification('No Stream', 'This item is not playable.', xbmcgui.NOTIFICATION_INFO)
        else:
            if not self.security_manager.verify_repository_installed():
                self.security_manager.show_repository_required_message()
                xbmcplugin.endOfDirectory(self.handle)
                return
            self.menu_manager.list_items(is_main_list=True)
